<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main_Model extends CI_Model
{
  
    public function __construct()
	{
		parent::__construct();
	}


    public function location()
    {
        //data is retrive from this query
        $sql = "SELECT sublocation FROM backend_warehouse.set_sublocation ORDER BY sublocation DESC";
        $query = $this->db->query($sql);
        return $query;
        
    }

    public function login_data($username, $userpass)
    {
        //data is retrive from this query
        $sql = "SELECT * FROM backend_warehouse.set_user WHERE user_name='$username' AND user_password='$userpass'";
        $query = $this->db->query($sql);
        return $query->num_rows();
        
    }
    
    public function home_data()  
    {  
        //data is retrive from this query
       /* $sql = "SELECT * FROM backend_warehouse.module_menuci WHERE hide_menu != '1' order by Sequence";*/
       $sql = "SELECT a.* FROM backend_warehouse.module_menu a INNER JOIN backend_warehouse.set_user_group_webmodule b ON a.`module_name`=b.module_name INNER JOIN backend_warehouse.set_user_group c ON b.user_group_guid=c.user_group_guid INNER JOIN backend_warehouse.set_user d ON d.user_group_guid=c.user_group_guid  WHERE hide_menu<>1 AND user_name='".$_SESSION['username']."' ORDER BY Sequence";
        $query = $this->db->query($sql);  
        return $query;  
    }

    public function general_post_grn($data,$grn_guid)
    {
        $this->db->where('grn_guid', $grn_guid);
        $this->db->update('backend_warehouse.d_grn', $data);
    }

    public function general_post_trx_out($data,$trans_guid)
    {
        $this->db->where('trans_guid', $trans_guid);
        $this->db->update('backend_warehouse.b_trans', $data);
        // echo $this->db->last_query();die;
    }

    public function general_post_trx_rec_child($data, $child_guid)
    {
        $this->db->where('child_guid', $child_guid);
        $this->db->update('backend_warehouse.b_trans_c', $data);
        // echo $this->db->last_query();die;
    }

    public function general_post_trx_rec($data, $trans_guid)
    {
        $this->db->where('trans_guid', $trans_guid);
        $this->db->update('backend_warehouse.b_trans', $data);
        // echo $this->db->last_query();die;
    }

    public function b_transfer_rec_post($trans_guid)  
    {  
        //data is retrive from this query
        $sql = "CALL backend_warehouse.b_transfer_rec_post('$trans_guid')";
        $query = $this->db->query($sql);  
    }

    public function add_detail($data)
    {
        $this->db->insert('backend_warehouse.set_user_group_setting', $data);
       /* echo $this->db->last_query();die;*/
    }

        public function update_details($data,$guid)
    {
        $this->db->where('user_group_guid',$guid);
        $this->db->update('backend_warehouse.set_user_group_setting', $data);
    }
       
       

    
}
?> 
