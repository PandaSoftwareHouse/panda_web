<?php 
'session_start()' 
?>
<style>

@media screen and (max-width: 768px) {
  
  p,input,div,span,h4 {
    font-size: 90%;
  }
  h1 {
    font-size: 20px;  
  }
  h4 {
    font-size: 18px;  
  }
  h3 {
    font-size: 20px;  
  }
  input {
    font-size: 16px;
  }
  p {
    font-size: 12px;
  }
  font{
    font-size: 16px;
  }
  h1.page-head-line{
    font-size: 25px;
  }
  td {
    font-size: 12px;
  }
  a.tab-head {
    font-size: 10px;
  }
}

</style>

<script type="text/javascript">

</script>
<!--onload Init
onload="window.location.reload() "-->
<body onload="document.refresh();">
    <div id="wrapper">
        
        <div id="page-inner">

            <div class="row">
                <div class="col-md-12">

                    <h1 class="page-head-line">
                        <a href="<?php echo site_url('logout_c/logout')?>" style="float:right">
                        <i class="fa fa-sign-out" style="color:#4380B8"></i></a>
                        
                        <a href="<?php echo site_url('main_controller/home')?>" style="float:right">
                        <i class="fa fa-home" style="color:#4380B8;margin-right:20px"></i></a>
                        <?php if ($_SESSION['show_cost'] == '1')
                                        {
                                      ?>
                        <a href="<?php echo site_url('PcheckerCost_controller/scan_result')?>?barcode=<?php echo $_SESSION['barcode']?>" style="float:right">
                        <i class="fa fa-arrow-left" style="color:#4380B8;margin-right:20px"></i></a>
                        <?php } else { ?>
                        <a href="<?php echo site_url('Pchecker_controller/scan_result')?>?barcode=<?php echo $_SESSION['barcode']?>" style="float:right">
                        <i class="fa fa-arrow-left" style="color:#4380B8;margin-right:20px"></i></a>
                        <?php } ?>
                        <font>SKU INFO</font>
                    </h1>
                        <!--<h1 class="page-subhead-line"></h1>-->
                </div>
            </div>      
                <!--1-->
            
              <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                      <?php // echo var_dump($_SESSION) ?>
                        <div class="tabbable" id="tabs-577039">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a class="tab-head" href="#panel-360876" data-toggle="tab">Item Details</a>
                                </li>
                                <li >
                                    <a class="tab-head" href="#panel-107683" data-toggle="tab">Promotion</a>
                                </li>
                                <?php if ($_SESSION['show_cost'] == '1')
                                        {
                                      ?>
                                <li >
                                    <a class="tab-head" href="#panel-purchase_details" data-toggle="tab">Purchase Details</a>
                                </li>

                                <?php }  ?>
                                <li >
                                    <a class="tab-head" href="#panel-itemlink" data-toggle="tab">Item Link</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="panel-360876">
                                    <br>
                                    <?php foreach($item_details as $p)
                                    {
                                      ?>
                                      <h3 ><b class="font"><?php echo $p['Description']; ?></b></h3>

                                      <table>
                                      <font style="display:inline-block;margin-right:9px">
                                      
                                      <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>Item Code :</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $p['itemcode']; ?></b>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>Barcode :</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $p['Barcode']; ?></b>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>Tax Code Purchase:</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $p['tax_code_purchase']; ?></b>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>Tax Code Supply :</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $p['tax_code_supply']; ?></b>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>Item Type :</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $p['itemtype']; ?></b>
                                        </td>
                                      </tr>
                                      </font>
                                      </table>

                                      <table>
                                      <font style="display:inline-block;margin-right:9px">
                                      <tr>
                                        <td style="width:220px;font-size:16px">
                                        <b>Selling Price (include tax) :</b>
                                        </td>
                                        <td style="width:150px;font-size:16px">
                                        <b> RM </b><?php echo $p['price_include_tax']; ?>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td style="width:220px;font-size:16px">
                                        <b>Selling Price (exclude tax) :</b>
                                        </td>
                                        <td style="width:150px;font-size:16px">
                                        <b> RM </b><?php echo $p['sellingprice']; ?>
                                        </td>
                                      </tr>
                                      <?php 
                                        if ($_SESSION['show_cost'] == '1')
                                        {
                                      ?>
                                      <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>Average Cost :</b>
                                        </td>
                                        <td style="width:150px;font-size:16px">
                                        <b> RM </b><?php echo $p['averagecost']; ?>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $p['avg_profit']; ?></b>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>Last Cost :</b>
                                        </td>
                                        <td style="width:150px;font-size:16px">
                                        <b> RM </b><?php echo $p["lastcost"]; ?>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $p["last_profit"]; ?></b>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>Listed Cost :</b>
                                        </td>
                                        <td style="width:150px;font-size:16px">
                                        <b> RM </b><?php echo $p["stdcost"]; ?>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $p["std_profit"]; ?></b>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>FIFO Cost :</b>
                                        </td>
                                        <td style="width:150px;font-size:16px">
                                        <b> RM </b><?php echo $p["fifocost"]; ?>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $p["fifo_profit"]; ?></b>
                                        </td>
                                      </tr>

                                      <?php }
                                       ?>
                                      </font>
                                      </table>
                                      <?php
                                    }
                                    
                                    ?>

                                    <?php foreach($item_qoh as $i): ?>
                                    <table>
                                      <font style="display:inline-block;margin-right:9px">
                                      <tr>
                                      <td style="width:200px;font-size:16px">
                                      <b>All Packsize QOH :</b>
                                      </td>
                                      <td style="width:200px;font-size:16px">
                                      <b><?php echo $i["qoh"]; ?></b>
                                      </td>
                                      </tr>
                                      </font>
                                    </table>
                                    <?php endforeach;?>

                                    <?php foreach($item_qoh_c as $k): ?>
                                      <table>
                                        <font style="display:inline-block;margin-right:9px">
                                        <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>Min. Date :</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $k["min_date"]; ?></b>
                                        </td>
                                        </tr>
                                        <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>Max. Date :</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $k["max_date"]; ?></b>
                                        </td>
                                        </tr>
                                        <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>ADS :</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $k["ads"]; ?></b>
                                        </td>
                                        </tr>
                                        <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>AWS :</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $k["aws"]; ?></b>
                                        </td>
                                        </tr>
                                        <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>AMS :</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $k["ams"]; ?></b>
                                        </td>
                                        </tr>
                                        <tr>
                                        <td style="width:200px;font-size:16px">
                                        <b>DOH :</b>
                                        </td>
                                        <td style="width:200px;font-size:16px">
                                        <b><?php echo $k["doh"]; ?></b>
                                        </td>
                                        </tr>
                                        </font>
                                      </table>
                                    <?php endforeach;?>


                                </div>
                                
                                <div class="tab-pane " id="panel-107683">
                                  <br>
                                  <div style="overflow-x:auto;" >
                                  
                                    <table class="table table-striped table-bordered table-hover" style="width:100">
                                    <thead>
                                        <tr>
                                            <td ><b>REF NO</b></td>
                                            <td ><b>Date From</b></td>
                                            <td ><b>Date To</b></td>
                                            <td ><b>Outlet</b></td>
                                            <td ><b>Card Type</b></td>
                                            <td ><b>Price (Before Discount)</b></td>
                                            <td ><b>Discount</b></td>
                                            <td ><b>Price Net</b></td>
                                            <td ><b>Promo Type</b></td>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php if($item_promo)
                                    {
                                     foreach($item_promo as $j): ?>
                                        <tr>
                                  
                                          <td><?php echo $j["refno"]; ?></td>

                                          <td><?php echo $j["datefrom"]; ?></td>
                                        
                                          <td><?php echo $j["dateto"]; ?></td>
                                        
                                          <td><?php echo $j["loc_group"]; ?></td>

                                          <td><?php echo $j["cardtype"]; ?></td>

                                          <td><?php echo $j["price_target"]; ?></td>
                                        
                                          <td><?php echo $j["discount"]; ?></td>
                                        
                                          <td><?php echo $j["price_net"]; ?></td>

                                          <td><?php echo $j["promo_type"]; ?></td>
                                          
                                        </tr>

                                    <?php 
                                    endforeach;
                                    }
                                    else
                                    {
                                    ?>

                                        <tr>
                                            <td colspan="9" style="text-align:center;">No Data Found</td>
                                        </tr>

                                    <?php
                                    }
                                    ?>

                                    </tbody>
                                    </table>
                                  </div> 
                                </div>

                                <?php  if ($_SESSION['show_cost'] == '1')
                                        {
                                      ?>
                                <div class="tab-pane" id="panel-purchase_details">
                                <br>
                                <h4><b>PURCHASE ORDER  :</b></h4>
                                    <div style="overflow-x:auto;" >
                                    <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <td><b>REF NO</b></td>
                                            <td><b>Supplier Code</b></td>
                                            <td><b>PO Date</b></td>
                                            <td><b>Quantity</b></td>
                                            <td><b>Deliver Date</b></td>
                                            <td><b>Expiry Date</b></td>
                                        </tr>
                                    </thead>

                                    <tbody>

                                    <?php if($po_details)
                                    {
                                     foreach($po_details as $m): ?>

                                        <tr>
                                          <td><?php echo $m["refno"]; ?></td>
                                        
                                          <td><?php echo $m["supcode"]; ?></td>
                                            
                                          <td><?php echo $m["podate"]; ?></td>
                                        
                                          <td><?php echo $m["qty_order"]; ?></td>
                                        
                                          <td><?php echo $m["deliverdate"]; ?></td>

                                          <td><?php echo $m["expiry_date"]; ?></td>
                                        </tr> 
                                    
                                       
                                    <?php
                                    endforeach;
                                    }
                                    else
                                    {
                                    ?>
                                         <tr>
                                            <td colspan="6" style="text-align:center;">No Data Found</td>
                                        </tr>


                                    <?php
                                    }
                                    ?>
                                    </tbody>
                                    </table>

                                    </div>

                                     <h4><b>GOOD RECEIVED  :</b></h4>

                                    <div style="overflow-x:auto;" >
                                    <table class="table table-striped table-bordered table-hover">
                                      <thead>
                                          <tr>
                                              <td><b>REF NO</b></td>
                                              <td><b>Supplier Code</b></td>
                                              <td><b>GR Date</b></td>
                                              <td><b>Quantity Recieved</b></td>
                                              <td><b>Net Unit Price</b></td>
                                          </tr>
                                      </thead>

                                      <tbody>

                                      <?php if($gr_details)
                                      {
                                       foreach($gr_details as $j): ?>

                                          <tr>
                                            <td><?php echo $j["refno"]; ?></td>
                                          
                                            <td><?php echo $j["supcode"]; ?></td>

                                            <td><?php echo $j["grdate"]; ?></td>
                                          
                                            <td><?php echo $j["qty_received"]; ?></td>
                                          
                                            <td><?php echo $j["netunitprice"]; ?></td>
                                          </tr>
                                     
                                      <?php 
                                      endforeach;
                                      }
                                      else
                                      {
                                      ?>
                                           <tr>
                                              <td colspan="6" style="text-align:center;">No Data Found</td>
                                          </tr>


                                      <?php
                                      }
                                      ?>

                                      </tbody>
                                    </table>
                                    </div>

                                </div>

                                <?php } ?>

                                <div class="tab-pane" id="panel-itemlink">
                                <br>

                                    <div style="overflow-x:auto;" >
                                     <table id="myTable" class="tablesorter table table-striped table-bordered table-hovers">
                                        <thead style="cursor:s-resize">
                                          <tr>
                                        
                                            <th style="text-align:center;">Item Code</th>
                                            <th style="text-align:center;">Price</th>
                                            <th style="text-align:center;">Pack Size</th>
                                            <th style="text-align:center;">QOH</th>
                                            <th style="text-align:center;">Total QOH</th>
                                            <th style="text-align:center;">Description</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <?php
                                              foreach ($itemlink->result() as $row)
                                              {
                                                  ?>
                                                  <tr>
                                                    <td style="text-align:center;font-size: 12px"><?php echo $row->itemcode; ?></td>
                                                    <td style="text-align:center;font-size: 12px"><?php echo $row->sellingprice; ?></td>
                                                    <td style="text-align:center;font-size: 12px"><?php echo $row->packsize; ?></td>
                                                    <td style="text-align:center;font-size: 12px"><?php echo $row->onhandqty; ?></td>
                                                    <td style="text-align:center;font-size: 12px"><?php echo $row->psqoh; ?></td>
                                                    <td style="text-align:center;font-size: 12px"><?php echo $row->description; ?></td>
                                                  </tr>
                                                  <?php
                                              }
                                          ?> 
                                        </tbody>
                                      </table>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            
                        

                
   
        </div>
            <!-- /. PAGE INNER  -->
        <!--</div>-->
        <!-- /. PAGE WRAPPER  -->
    </div>