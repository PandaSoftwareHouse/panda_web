<html>
<body>
<div class="container">
<table width="200" border="0">
  <tr>
    <td width="120"><h5><b>SIMPLE SO</b><br>
    </h5></td>
    <td width="20"><a href="<?php echo site_url('Simpleso_controller/main')?>" style="float:right"><img src="<?php echo base_url('assets/icons/back.jpg'); ?>"></a>
    </td>
    <td width="5">&nbsp;</td>
    <td width="20"><a href="<?php echo site_url('main_controller/home')?>" style="float:right"><img src="<?php echo base_url('assets/icons/home.jpg');?>"></a></td>
    <td width="5">&nbsp;</td>
    <td width="20"><a href="<?php echo site_url('logout_c/logout')?>" style="float:right"><img src="<?php echo base_url('assets/icons/sign-out.jpg');?>"></a></td>
  </tr>
</table>
<form role="form" method="POST" id="myForm" action="<?php echo site_url('simpleso_controller/add_process'); ?>">
  <label for="remarks">Remarks :</label><br>
  <input type="text" style="background-color: #e6fff2" class="form-control input-sm" placeholder="Remarks" name="remarks" id="autofocus" required autofocus onblur="this.focus()"/>
</form>
<p>&nbsp;</p>
</div>
</body>
</html>

