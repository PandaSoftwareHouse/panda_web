<body onload="document.refresh();">
<div class ="container">
<table width="200" border="0">
  <tr>
    <td width="120">
    <h5><b>SKU INFO </b></h5></td>
    <td width="20"><a href="<?php echo site_url('Pchecker_controller/scan_result')?>?barcode=<?php echo $_SESSION['barcode']?>"><img src="<?php echo base_url('assets/icons/back.jpg'); ?>"></a></td>
    <td width="5">&nbsp;</td>
    <td width="20"><a href="<?php echo site_url('main_controller/home')?>" style="float:right"><img src="<?php echo base_url('assets/icons/home.jpg');?>"></a></td>
    <td width="5">&nbsp;</td>
    <td width="20"><a href="<?php echo site_url('logout_c/logout')?>" style="float:right"><img src="<?php echo base_url('assets/icons/sign-out.jpg');?>"></a></td>
  </tr>
</table>


<div class="panel-heading"><b>Item Details</b></div>
    <div class="panel-body">

<?php foreach($item_details as $p)
  {
?>
<h5><b class="font"><?php echo $p['Description']; ?></b></h5>
<p>
<b>Item Code :<?php echo $p['itemcode']; ?></b><br>
<b>Barcode :<?php echo $p['Barcode']; ?></b><br>                                      
<b>Tax Code Purchase:<?php echo $p['tax_code_purchase']; ?></b><br>
<b>Tax Code Supply :<?php echo $p['tax_code_supply']; ?></b><br>
<b>Item Type :<?php echo $p['itemtype']; ?></b><br><br>
<b>Selling Price (before tax) :RM <?php echo $p['sellingprice']; ?></b><br>
<b>Selling Price (after tax) :RM <?php echo $p['price_include_tax']; ?><br>
<?php if ($_SESSION['show_cost'] == '1') { ?>
<b>Average Cost :RM <?php echo $p['averagecost']; ?></b><br>
<b>Last Cost :RM <?php echo $p["lastcost"]; ?> <?php echo $p["last_profit"]; ?></b><br>
<b>Listed Cost :RM <?php echo $p["stdcost"]; ?> <?php echo $p["std_profit"]; ?>
<b>FIFO Cost :RM<?php echo $p["fifocost"]; ?> <?php echo $p["fifo_profit"]; ?></b><br>
<?php } ?>

<?php
  }
?>
<br>
<?php foreach($item_qoh as $i): ?>
<b>All Packsize QOH :<?php echo $i["qoh"]; ?></b>
<?php endforeach;?>
<br>
<br>
<?php foreach($item_qoh_c as $k): ?>
<b>Min. Date :<?php echo $k["min_date"]; ?></b><br>                                    
<b>Max. Date :<?php echo $k["max_date"]; ?></b><br>
<b>ADS :<?php echo $k["ads"]; ?></b><br>
<b>AWS :<?php echo $k["aws"]; ?></b><br>
<b>AMS :<?php echo $k["ams"]; ?></b><br>
<b>DOH :<?php echo $k["doh"]; ?></b><br>                                     
                                      
<?php endforeach;?>
    </div>



<div class="panel-heading"><b>Promotion</b></div>
    <div class="panel-body">
      <table class="cTable">
        <thead>
            <tr>
                <td class="cTD" ><b>REF NO</b></td>
                <td class="cTD" ><b>Date From</b></td>
                <td class="cTD" ><b>Date To</b></td>
                <td class="cTD" ><b>Outlet</b></td>
                <td class="cTD" ><b>Card Type</b></td>
                <td class="cTD" ><b>Price (Before Discount)</b></td>
                <td class="cTD" ><b>Discount</b></td>
                <td class="cTD" ><b>Price Net</b></td>
                <td class="cTD" ><b>Promo Type</b></td>
            </tr>
        </thead>
        <tbody>
          <?php if($item_promo)
            {
              foreach($item_promo as $j):
          ?>
          <tr>
            <td class="cTD"><?php echo $j["refno"]; ?></td>
            <td class="cTD"><?php echo $j["datefrom"]; ?></td>                                        
            <td class="cTD"><?php echo $j["dateto"]; ?></td>                                        
            <td class="cTD"><?php echo $j["loc_group"]; ?></td>
            <td class="cTD"><?php echo $j["cardtype"]; ?></td>
            <td class="cTD"><?php echo $j["price_target"]; ?></td>                                        
            <td class="cTD"><?php echo $j["discount"]; ?></td>                                        
            <td class="cTD"><?php echo $j["price_net"]; ?></td>
            <td class="cTD"><?php echo $j["promo_type"]; ?></td>                                          
          </tr>
            <?php 
              endforeach;
              }
              else
              {           
            ?>
            <tr>
              <td class="cTD" colspan="9" style="text-align:center;">No Data Found</td>
            </tr>
              <?php
                }
              ?>  
        </tbody>
      </table>
    </div>
<?php if ($_SESSION['show_cost'] == '1') { ?>
<div class="panel-heading"><b>Purchase Details</b></div>    
  <div class="panel-body">

  <h5><b>PURCHASE ORDER  :</b></h5>
                                    
  <table class="cTable">
  <thead>
      <tr>
          <td class="cTD"><b>REF NO</b></td>
          <td class="cTD"><b>Supplier Code</b></td>
          <td class="cTD"><b>PO Date</b></td>
          <td class="cTD"><b>Quantity</b></td>
          <td class="cTD"><b>Deliver Date</b></td>
          <td class="cTD"><b>Expiry Date</b></td>
      </tr>
  </thead>
  <tbody>
  <?php if($po_details)
  {
    foreach($po_details as $m): ?>
  <tr>
    <td class="cTD"><?php echo $m["refno"]; ?></td>                                
    <td class="cTD"><?php echo $m["supcode"]; ?></td>     
    <td class="cTD"><?php echo $m["podate"]; ?></td>
    <td class="cTD"><?php echo $m["qty_order"]; ?></td>
    <td class="cTD"><?php echo $m["deliverdate"]; ?></td>
    <td class="cTD"><?php echo $m["expiry_date"]; ?></td>
  </tr> 
  <?php
  endforeach;
    }
  else
    {
  ?>
    <tr>
      <td class="cTD" colspan="6" style="text-align:center;">No Data Found</td>
    </tr>
  <?php
    }
  ?>
</tbody>
</table>

<h5><b>GOOD RECEIVED  :</b></h5>
<table class="cTable">
<thead>
    <tr>
        <td class="cTD"><b>REF NO</b></td>
        <td class="cTD"><b>Supplier Code</b></td>
        <td class="cTD"><b>GR Date</b></td>
        <td class="cTD"><b>Quantity Recieved</b></td>
        <td class="cTD"><b>Net Unit Price</b></td>
    </tr>
</thead>

<tbody>

<?php if($gr_details)
{
  foreach($gr_details as $j): ?>

    <tr>
      <td class="cTD"><?php echo $j["refno"]; ?></td>                                          
      <td class="cTD"><?php echo $j["supcode"]; ?></td>
      <td class="cTD"><?php echo $j["grdate"]; ?></td>                                          
      <td class="cTD"><?php echo $j["qty_received"]; ?></td>                                          
      <td class="cTD"><?php echo $j["netunitprice"]; ?></td>
    </tr>
                                     
<?php 
endforeach;
}
else
{
?>
      <tr>
        <td colspan="6" class="cTD" style="text-align:center;">No Data Found</td>
    </tr>
<?php
}
?>

</tbody>
</table>
    
</div>
<?php } ?>

<div class="panel-heading"><b>Item Link</b></div>
    <div class="panel-body">
      <table class="cTable">
        <thead>
            <tr>
                <td class="cTD" ><b>Itemcode</b></td>
                <td class="cTD" ><b>Price</b></td>
                <td class="cTD" ><b>Pack Size</b></td>
                <td class="cTD" ><b>QOH</b></td>
                <td class="cTD" ><b>Total QOH</b></td>
                <td class="cTD" ><b>Description</b></td>
            </tr>
        </thead>
        <tbody>
          <?php
            foreach ($itemlink->result() as $row)
            {
          ?>
          <tr>
            <td class="cTD"><?php echo $row->itemcode; ?></td>
            <td class="cTD"><?php echo $row->sellingprice; ?></td>                                        
            <td class="cTD"><?php echo $row->packsize; ?></td>                                        
            <td class="cTD"><?php echo $row->onhandqty; ?></td>  
            <td class="cTD"><?php echo $row->psqoh; ?></td>  
            <td class="cTD"><?php echo $row->description; ?></td>                                 
          </tr>
              <?php
                }
              ?>  
        </tbody>
      </table>
    </div>
