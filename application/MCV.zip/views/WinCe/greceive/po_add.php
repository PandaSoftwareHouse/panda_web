<html>
<body>
<div class="container">
<table width="200" border="0">
  <tr>
    <td width="120"><h5><b>GRN BY PO</b></h5><small><b><?php echo $method?></b></small></td>
    <td width="20"><a href="<?php echo $back ?>">
    <img src="<?php echo base_url('assets/icons/back.jpg'); ?>"></a></td>
    <td width="5">&nbsp;</td>
    <td width="20"><a href="<?php echo site_url('main_controller/home')?>" style="float:right"><img src="<?php echo base_url('assets/icons/home.jpg');?>"></a></td>
    <td width="5">&nbsp;</td>
    <td width="20"><a href="<?php echo site_url('logout_c/logout')?>" style="float:right"><img src="<?php echo base_url('assets/icons/sign-out.jpg');?>"></a></td>
  </tr>
</table>
	
<form role="form" method="POST" id="myForm" action="<?php echo $form_action ?>">

<h5><b>PO No: </b><?php echo $po_no?></h5>
<h5><b>Supplier Name: </b><?php echo $sname?></h5>
<label><b>DO No :</b></label><br>
<input autofocus onfocus="this.select()" type="text" name="do_no" style="background-color:#ffff99" class="form-control"
  <?php
      foreach($po_details->result() as $row)
      {
          ?>
          value="<?php echo $row->do_no?>"
          <?php
      }
  ?>
          />
 <br>                                                   
<label><b>Invoice NO :</b></label><br>
<input type="text" name="inv_no" style="background-color:#80ff80" class="form-control"
  <?php
      foreach($po_details->result() as $row)
      {
          ?>
          value="<?php echo $row->inv_no?>"
          <?php
      }
  ?>
  />
<br><br>
<input type="submit" name="button" id="button" class="btn_success" value="SAVE"onclick="return check()">
 
</form>
<p>&nbsp;</p>
</div>
</body>
</html>

