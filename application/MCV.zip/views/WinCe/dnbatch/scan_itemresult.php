<html>
<body>
<div class="container">
<table width="200" border="0">
  <tr>
    <td width="120"><h5><b>DN Batch</b><br>
    </h5></td>
    <td width="20"><a onclick="history.go(-1); else false;" href="<?php echo site_url('Dnbatch_controller/scan_item')?>" style="float:right"><img src="<?php echo base_url('assets/icons/back.jpg');?>"></a></td>
    <td width="5">&nbsp;</td>
    <td width="20"><a href="<?php echo site_url('main_controller/home')?>" style="float:right"><img src="<?php echo base_url('assets/icons/home.jpg');?>"></a></td>
    <td width="5">&nbsp;</td>
    <td width="20"><a href="<?php echo site_url('logout_c/logout')?>" style="float:right"><img src="<?php echo base_url('assets/icons/sign-out.jpg');?>"></a></td>
  </tr>
</table>
<form role="form" method="POST" id="myForm" action="<?php echo site_url('Dnbatch_controller/add_qty'); ?>">
 <?php 
    foreach($item->result() as $row)
    {
 ?>
	<p><?php echo $_SESSION['batch_no'] ?><br>
	  <?php echo $row->name; ?><br>
	  <b>Description : </b><?php echo $row->description?><br>
	  <b>Barcode: </b><?php echo $row->barcode;?>
	</p>
    <input value="<?php echo $row->itemcode?>" name="itemcode" type="hidden">
    <input value="<?php echo $row->barcode?>" name="barcode" type="hidden">
  
  <?php
      }
  ?>  
    <p>
      <label for="textfield"><b>Qty :</b></label>
      <br>
      <input autofocus required value="<?php foreach($qty->result() as $row) { echo $row->qty; } ?>" type="number" step ="any" name="iqty" size="5" onfocus="this.select()" style="text-align:center;background-color: #e6fff2" />
    </p>
    <p>
      <input type="submit" value="SAVE" name="view" class="btn_success">
    </p>
</form>
<p>&nbsp;</p>
</div>
</body>
</html>

