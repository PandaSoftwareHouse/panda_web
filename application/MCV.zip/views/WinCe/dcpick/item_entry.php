<html>
<script type="text/javascript">

$(document).ready( function() {
  $('#id').click( function( event_details ) {
    $(this).select();
  });
});

</script>
<body>
<div class="container">
<table width="200" border="0">
  <tr>
    <td width="150"><h5><b>DC MOBILE PICK</b></h5>
        <small><b><?php echo $dc_refno?></b></small></font> 
    </td>
    <td width="20"><a href="<?php echo site_url('dcpick_controller/scan_item_error')?>" style="float:right"><img src="<?php echo base_url('assets/icons/back.jpg');?>"></a></td>
    <td width="5">&nbsp;</td>
    <td width="20"><a href="<?php echo site_url('main_controller/home')?>" style="float:right"><img src="<?php echo base_url('assets/icons/home.jpg');?>"></a></td>
    <td width="5">&nbsp;</td>
    <td width="20"><a href="<?php echo site_url('logout_c/logout')?>" style="float:right"><img src="<?php echo base_url('assets/icons/sign-out.jpg');?>"></a></td>
  </tr>
</table>

<form role="form" method="POST" id="myForm" action="<?php echo site_url('dcpick_controller/item_entry_add')?>">
  <table class="cTable">
  <tbody>
     <?php 
        foreach($check_related_item->result() as $row)
        {
          ?>
          <tr><td class="cTD" style="text-align:center;"><b>Description: </b></td><td class="cTD"  style="text-align:left;"><?php echo $row->description;?></td></tr>
          <tr><td class="cTD" style="text-align:center;"><b>Barcode : </b></td><td class="cTD"  style="text-align:left;"><?php foreach($check_bar->result() as $cb) 
               { 
                 if($row->itemcode == $cb->itemcode) 
                     { 
                        echo $cb->barcode ; echo '<br>';
                     } 
               } ?></td></tr>
        <tr><td class="cTD" style="text-align:center;"><b>P/Size: </b><?php echo $row->packsize;?> </td><td class="cTD"  style="text-align:left;"><b>UM: </b><?php echo $row->um?></td></tr>
        <tr><td class="cTD" style="text-align:center;"><b>SinglePack QOH: </b></td><td class="cTD"  style="text-align:left;"><?php foreach($QOH->result() as $qoh) { 
           echo '&nbsp'; echo $qoh->SinglePackQOH; }?> </td></tr>
        <tr><td class="cTD" style="text-align:center;"><b>Size Req Info:</b></td><td class="cTD"  style="text-align:left;"> <?php echo $row->sizeinfo?></td> </tr>
        <tr><td class="cTD" style="text-align:center;"><b>Mobile Qty Info: </b></td><td class="cTD"  style="text-align:left;"><?php echo $row->check_qty?> </td></tr>
        <input id="itemcode" value="<?php echo $row->itemcode?>" name="itemcode[]" type="hidden">
        <input value="<?php echo $row->description?>" name="description[]" type="hidden">
        <input value="<?php echo $row->packsize?>" name="packsize[]" type="hidden">
        <input value="<?php echo $row->um?>" name="um[]" type="hidden">
        <input value="<?php echo $row->sizeinfo?>" name="sizeinfo[]" type="hidden">

        <?php 
           }
           if( $_SESSION['soldbyweight'] == 0)
             { 
         ?>
        <tr><td  class="cTD" style="text-align:center;"><b> Qty: </b></td><td><input class="form-control" type="number" step="1" autofocus onfocus="this.select()" value="0" max="10000" style="text-align:center;width:80px;background-color:#ffff99" name="qty_input[]" /> </td></tr>
         <?php } 
             else { ?>
        <tr><td  class="cTD" style="text-align:center;"><b> Qty: </b></td><td><input class="form-control"  type="number" step="any" autofocus onfocus="this.select()" value="0" max="10000" style="text-align:center;width:80px;background-color:#ffff99" name="qty_input[]" /></td></tr>
          <?php } ?>
  </tbody>

</table>

<input type="submit" name="submit" value="SAVE" class="btn_success">
</form>
<p> &nbsp;</p>
  </div>  
</body>
</html>
