<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stktake_controller extends CI_Controller {
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('stktake_model');
        $this->load->model('general_scan_model');
        $this->load->library(array('session'));
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper(array('form','url'));
        $this->load->helper('html');
        $this->load->database();
        $this->load->library('form_validation');

    }


    public function scan_userID()
    {
        
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {

       // $location = $this->input->post('location');
            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {
                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/stktake/scan_userID');
                }
            else
                {
                    $this->load->view('header');
                    $this->load->view('stktake/scan_userID');
                    $this->load->view('footer');
                }    
        }
        else
        {
            redirect('main_controller');
        }
    }


    public function scan_binID()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        { 
        
        $user_ID = $this->input->post('user_ID');
        $bin_ID = '';
            
            if ($this->input->post('user_ID') != "")
            {
                $data['trans_guid'] = $result = $this->stktake_model->store_trans();
    
                    $user_ID_Data = array(
                        'user_ID' => $user_ID,
                        'bin_ID' => $bin_ID,
                        'trans_guid' =>$result->row('TRANS_GUID')
                        );
                    $this->session->set_userdata($user_ID_Data);
    
                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                    if(strpos($browser_id,"Windows CE"))
                        {
                            $this->load->view('WinCe/header');
                            $this->load->view('WinCe/stktake/scan_binID', $data, $user_ID_Data);
                        }
                    else
                        {
                            $this->load->view('header');
                            $this->load->view('stktake/scan_binID', $data, $user_ID_Data);
                            $this->load->view('footer');
                        }    
                    
               
            }
            else
            {
                $user_ID = $_REQUEST['user_ID'];
                $data['trans_guid'] = $result = $this->stktake_model->store_trans();
                
                    $user_ID_Data = array(
                        'user_ID' => $user_ID,
                        'bin_ID' => $bin_ID,
                        'trans_guid' =>$result->row('TRANS_GUID')
                        );
                    $this->session->set_userdata($user_ID_Data);
                    
                $browser_id = $_SERVER["HTTP_USER_AGENT"];
                    if(strpos($browser_id,"Windows CE"))
                        {
                            $this->load->view('WinCe/header');
                            $this->load->view('WinCe/stktake/scan_binID', $data, $user_ID_Data);
                        }
                    else
                        {
                            $this->load->view('header');
                            $this->load->view('stktake/scan_binID', $data, $user_ID_Data);
                            $this->load->view('footer');
                        }    

            }
        }
        else
        {
            redirect('main_controller');
        }
        
    }


    public function scan_item()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        { 
        
            $bin_ID = $this->input->post('bin_ID');
            $user_ID = $this->input->post('user_ID');
            
                
            if ($this->input->post('bin_ID') != "")
            {

                $data['binID'] = $result  = $this->stktake_model->check_binID($bin_ID);
                $checksub  = $this->stktake_model->sublocation($bin_ID);
                $sublocation = $checksub->row('sublocation');
                $trans_guid = $_SESSION['trans_guid'];
                $caption = $this->db->query("SELECT IF(send_print = '1', CONCAT('Printed'), ' ') AS printinfo 
                FROM backend_stktake.`stk_trans`
                WHERE `trans_guid` = '$trans_guid'
                AND `bin_id` = '$bin_ID'
                LIMIT 1");
                $printinfo = $caption->row('printinfo');
                if($result->num_rows() != 0 )
                {
                    $bin_ID_Data = array(
                        'bin_ID' => $bin_ID,
                        'user_ID' => $user_ID,
                        'sublocation' => $sublocation,
                        'printinfo' => $printinfo,
                        );
                    $this->session->set_userdata($bin_ID_Data);
                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                    if(strpos($browser_id,"Windows CE"))
                        {
                            $this->load->view('WinCe/header');
                            $this->load->view('WinCe/stktake/scan_item', $bin_ID_Data);
                        }
                    else
                        {
                            $this->load->view('header');
                            $this->load->view('stktake/scan_item', $bin_ID_Data);
                            $this->load->view('footer');
                        }    
                }
                else
                {
                    echo "<script>
                    alert('Bin ID Not Exist.');
                    </script>";
                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                    if(strpos($browser_id,"Windows CE"))
                        {
                            $this->load->view('WinCe/header');
                            $this->load->view('WinCe/stktake/scan_binID');
                        }
                    else
                        {
                            $this->load->view('header');
                            $this->load->view('stktake/scan_binID');
                            $this->load->view('footer');
                        }    
                } 
            }
            else
            {

                $bin_ID = $_REQUEST['bin_ID'];
                $user_ID = $_REQUEST['user_ID'];
                $checksub  = $this->stktake_model->sublocation($bin_ID);
                $sublocation = $checksub->row('sublocation');
                $trans_guid = $_SESSION['trans_guid'];
                $caption = $this->db->query("SELECT IF(send_print = '1', CONCAT('Printed'), ' ') AS printinfo 
                FROM backend_stktake.`stk_trans`
                WHERE `trans_guid` = '$trans_guid'
                AND `bin_id` = '$bin_ID'
                LIMIT 1");
                $printinfo = $caption->row('printinfo');
                $bin_ID_Data = array(
                    'bin_ID' => $bin_ID,
                    'user_ID' => $user_ID,
                    'sublocation' => $sublocation,
                    'printinfo' => $printinfo,
                    );
                    $this->session->set_userdata($bin_ID_Data);
                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                    if(strpos($browser_id,"Windows CE"))
                        {
                            $this->load->view('WinCe/header');
                            $this->load->view('WinCe/stktake/scan_item', $bin_ID_Data);
                        }
                    else
                        {
                            $this->load->view('header');
                            $this->load->view('stktake/scan_item', $bin_ID_Data);
                            $this->load->view('footer');
                        }   

            }
        }
        else
        {
            redirect('main_controller');
        }
        
    }


    public function scan_item_result()
    {
        
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {
            $barcode = $this->input->post('barcode');

            if ($this->input->post('barcode') != "")
            {
            $module = 'Stock Take';

                       
             // check if need decode
            $barcode_type1 = $this->general_scan_model->check_itemmaster_all($barcode);
            

             if($barcode_type1-> num_rows() > 0 )
            {
                foreach($barcode_type1->result() as $row)
                {
                    $barcode_type = $row->barcodetype;
                    $getsellingprice = $row->sellingprice;
                    $getsoldbyweight = $row->soldbyweight;
                    $get_weight = '';
                }
            }
            else if ($barcode_type1-> num_rows() == 0 )
            {

                $barcode_type2 = $this->general_scan_model->check_itemmaster_18D($barcode);
                                 if($barcode_type2-> num_rows() > 0 )
                                {
                                    foreach($barcode_type2->result() as $row)
                                    {
                                        $barcode_type = $row->barcodetype;
                                        $getsellingprice = $row->sellingprice;
                                        $getsoldbyweight = $row->soldbyweight;
                                    }
                                 }// end barcodetype2
                                 else
                                 {
                                    $barcode_type = '';
                                 }

                $eighteenD = $this->general_scan_model->check_decode($module);
                if ($eighteenD->num_rows() != 0 )
                {
                    if($barcode != '0')
                    {
                        foreach($eighteenD->result() as $row)
                        {
                        $weight_type_code               =  $row->weight_type_code;
                        $weight_capture_price           =  $row->weight_capture_price;
                        $weight_bar_pos_start           =  $row->weight_bar_pos_start;
                         $weight_bar_pos_count           =  $row->weight_bar_pos_count;
                        $weight_capture_factor          =  $row->weight_capture_factor;
                        $weight_capture_weight          =  $row->weight_capture_weight;
                        $weight_capture_pos_start       =  $row->weight_capture_pos_start;
                        $weight_capture_pos_count       =  $row->weight_capture_pos_count;
                        $weight_capture_weight_type     =  $row->weight_capture_weight_type;
                        $weight_capture_price_factor    =  $row->weight_capture_price_factor;
                        $weight_capture_price_pos_start =  $row->weight_capture_price_pos_start;
                        $weight_capture_price_pos_count =  $row->weight_capture_price_pos_count;
              

                        }
                        if ($weight_capture_weight == 1)
                        {
                            if($weight_capture_weight_type == 'actual weight' )
                            {
                                    if($barcode_type == 'Q') // sold by qty
                                    {
                                    $get_weight = substr($barcode, 
                                        $weight_capture_pos_start-1
                                        , $weight_capture_pos_count);
    
                                    }
                                    else // sold by weight
                                    {
                                    $get_weight = substr($barcode,$weight_capture_pos_start-1
                                                , $weight_capture_pos_count)/
                                                $weight_capture_factor;
                                    }
                               
                            }
                            else
                            {
                            $get_weight = (substr($barcode, $weight_capture_pos_start-1
                                        , $weight_capture_pos_count)/ $weight_capture_factor)  ;
                           /* /$getsellingprice;*/ 
                            } // end actual weight

                            $get_weight = round($get_weight,3);

                        }else //else weight capture weight
                        {
                             $get_weight = round($get_weight,3);
                        }

                        if($weight_capture_price == 1)
                        {
                        $get_price = substr($barcode, $weight_capture_price_pos_start-1,
                            $weight_capture_price_pos_count)/
                            $weight_capture_price_factor;
                        }
                        $get_price = round($get_price,3);

                        $temp_weight_price = array(
                                    'get_weight' =>$get_weight,
                                    'get_price' => $get_price,
                                    );
                                    $this->session->set_userdata($temp_weight_price); 

                        
                        if ( strlen($barcode)== '18')
                                   {
                                       /*$_barcode = substr($barcode,0,-11);*/
                                       $_barcode = substr($barcode, $weight_bar_pos_start-1,$weight_bar_pos_count);
                                       $barcode = $_barcode;
                                   }
                        else if ( strlen($barcode) == '13')
                                   {
                                       /*$_barcode = substr($barcode,0,-6);*/
                                        $_barcode = substr($barcode, $weight_bar_pos_start-1,$weight_bar_pos_count);
                                       $barcode = $_barcode;
                                   }
                    }// end if checking barcode = 0
                    else
                    {
                        echo 'direct click link mode';
                    }
                } // end 18D num_rows != 0
            } // end elseif num_rows() == 0
            else
            {
                echo 'barcode_type1 there something wrong laaa.';
            }
            $check = $this->stktake_model->check_guid($barcode);
            $check_im = $this->general_scan_model->check_itemcode($barcode);
                     if($check->num_rows() == 0 && $check_im->num_rows() != 0)
                     {
            $data['item']=$this->stktake_model->itemresult_new($barcode);
            $data['itemQty']=$this->stktake_model->itemQty($barcode);
            $data['detail']=$this->stktake_model->deptsubdept($barcode);
            
            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {
                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/stktake/scan_item_result', $data);
                }
            else
                {
                    $this->load->view('header');
                    $this->load->view('stktake/scan_item_result', $data);
                    $this->load->view('footer');
                }

            
                     }// end check num rows == 0      
               
                    else if ($check->num_rows() != 0 && $check_im->num_rows() != 0)
                    {
            $data['item']=$this->stktake_model->itemresult_new($barcode);
            $data['itemQty']=$this->stktake_model->itemQty($barcode);
            $data['detail']=$this->stktake_model->deptsubdept($barcode);
            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {
                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/stktake/edit_item_result', $data);
                }
            else
                {
                    $this->load->view('header');
                    $this->load->view('stktake/edit_item_result', $data);
                    $this->load->view('footer');
                }    
                    }
                    else
                    {
                         $this->session->set_flashdata('message', 'Barcode does not exist');
                         redirect('stktake_controller/scan_item?user_ID='.$_SESSION['user_ID']."&bin_ID=".$_SESSION['bin_ID']);
                    } // end else check numrows == 0
            } // end if barcode exist or not
        } // end login = true
        else
        {
            redirect('main_controller');
        } // end else login = false
    } // end function
 public function add_qty()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {

        
        $barcode = $this->input->post('barcode');
        $bin_ID = $this->input->post('bin_ID');
        $itemcode = $this->input->post('itemcode');
        $description = addslashes($this->input->post('description'));
        $itemlink = $this->input->post('itemlink');
        $iqty = $this->input->post('iqty');
        $defaultqty = $this->input->post('defaultqty');
        $qty = $this->input->post('qty');
        $trans_guid = $_SESSION['trans_guid'];
        $sublocation = $_SESSION['sublocation'];
    
        $totalqty  = $iqty+$defaultqty;

        $result = $this->stktake_model->add_qty($barcode,$itemcode,$description,$itemlink,$totalqty); 
        $result2 = $this->stktake_model->add_stk_trans();
        $result3 = $this->stktake_model->update_stk_trans();  

        $check_stkqoh = $this->db->query("SELECT * FROM backend_stktake.stk_qoh WHERE trans_guid='$trans_guid' AND itemcode='$itemcode' ");

        if ($check_stkqoh->num_rows() == 0 )
        {
            $add_stkqoh = $this->db->query("INSERT INTO backend_stktake.`stk_qoh` (TRANS_GUID,TRANS_CHILD,Location,Itemcode,Barcode) 
                VALUES('$trans_guid', REPLACE(UPPER(UUID()),'-',''), '$sublocation', '$itemcode', '$barcode')");
            $update_stkqoh = $this->db->query("UPDATE backend_stktake.stk_qoh m 
                INNER JOIN (SELECT b.`Location`,a.itemcode,IF(SUM(a.qty) IS NULL,0,SUM(a.qty)) AS sum_qty 
                FROM backend_stktake.`stk_trans` a 
                INNER JOIN  backend_stktake.set_bin b 
                ON a.`BIN_ID`=b.`BIN_NO` 
                WHERE a.trans_guid='$trans_guid'
                AND a.`Itemcode`='$itemcode'
                GROUP BY b.`Location`,a.itemcode) n 
                ON m.`Itemcode`=n.itemcode SET m.stk_qty=n.sum_qty 
                WHERE m.trans_guid='$trans_guid'
                AND m.`Itemcode`='$itemcode'");
            $edit_stkqoh = $this->db->query("UPDATE backend_stktake.stk_qoh SET Stk_Variance=stk_qty-qoh 
                WHERE trans_guid='$trans_guid' AND itemcode='$itemcode'");
            $result4 = $this->stktake_model->updateitemmasterinfo($itemcode); 
        }
        else
        {
            $update_stkqoh = $this->db->query("UPDATE backend_stktake.stk_qoh m 
                INNER JOIN (SELECT b.`Location`,a.itemcode,IF(SUM(a.qty) IS NULL,0,SUM(a.qty)) AS sum_qty 
                FROM backend_stktake.`stk_trans` a 
                INNER JOIN  backend_stktake.set_bin b 
                ON a.`BIN_ID`=b.`BIN_NO` 
                WHERE a.trans_guid='$trans_guid'
                AND a.`Itemcode`='$itemcode'
                GROUP BY b.`Location`,a.itemcode) n 
                ON m.`Itemcode`=n.itemcode SET m.stk_qty=n.sum_qty 
                WHERE m.trans_guid='$trans_guid'
                AND m.`Itemcode`='$itemcode'");           
            $edit_stkqoh = $this->db->query("UPDATE backend_stktake.stk_qoh SET Stk_Variance=stk_qty-qoh 
                WHERE trans_guid='$trans_guid' AND itemcode='$itemcode'");
        }   
                $browser_id = $_SERVER["HTTP_USER_AGENT"];
                if(strpos($browser_id,"Windows CE"))
                    {
                        $this->load->view('WinCe/header');
                        $this->load->view('WinCe/stktake/scan_item');
                    }
                else
                    {
                        $this->load->view('header');
                        $this->load->view('stktake/scan_item');
                        $this->load->view('footer');
                    }   
                
        }
        else
        {
            redirect('main_controller');
        }
    }


     public function edit_qty()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {
        $barcode = $this->input->post('barcode');
        $bin_ID = $this->input->post('bin_ID');
        $itemcode = $this->input->post('itemcode');
        $description = addslashes($this->input->post('description'));
        $itemlink = $this->input->post('itemlink');
        $iqty = $this->input->post('iqty');
        $defaultqty = $this->input->post('defaultqty');
        $qty = $this->input->post('qty');
        $trans_guid = $_SESSION['trans_guid'];
        $sublocation = $_SESSION['sublocation'];
    
        $totalqty  = $iqty+$defaultqty;
        
        $result = $this->stktake_model->edit_qty($barcode,$itemcode,$description,$itemlink,$totalqty);
        $result2 = $this->stktake_model->edit_stk_trans();

        $check_stkqoh = $this->db->query("SELECT * FROM backend_stktake.stk_qoh WHERE trans_guid='$trans_guid' AND itemcode='$itemcode' ");
        if ($check_stkqoh->num_rows() == 0 )
        {
            $add_stkqoh = $this->db->query("INSERT INTO backend_stktake.`stk_qoh` (TRANS_GUID,TRANS_CHILD,Location,Itemcode,Barcode) 
                VALUES('$trans_guid', REPLACE(UPPER(UUID()),'-',''), '$sublocation', '$itemcode', '$barcode')");
            $update_stkqoh = $this->db->query("UPDATE backend_stktake.stk_qoh m 
                INNER JOIN (SELECT b.`Location`,a.itemcode,IF(SUM(a.qty) IS NULL,0,SUM(a.qty)) AS sum_qty 
                FROM backend_stktake.`stk_trans` a 
                INNER JOIN  backend_stktake.set_bin b 
                ON a.`BIN_ID`=b.`BIN_NO` 
                WHERE a.trans_guid='$trans_guid'
                AND a.`Itemcode`='$itemcode'
                GROUP BY b.`Location`,a.itemcode) n 
                ON m.`Itemcode`=n.itemcode SET m.stk_qty=n.sum_qty 
                WHERE m.trans_guid='$trans_guid'
                AND m.`Itemcode`='$itemcode'");
            $edit_stkqoh = $this->db->query("UPDATE backend_stktake.stk_qoh SET Stk_Variance=stk_qty-qoh 
                WHERE trans_guid='$trans_guid' AND itemcode='$itemcode'");
        }
        else
        {
            $update_stkqoh = $this->db->query("UPDATE backend_stktake.stk_qoh m 
                INNER JOIN (SELECT b.`Location`,a.itemcode,IF(SUM(a.qty) IS NULL,0,SUM(a.qty)) AS sum_qty 
                FROM backend_stktake.`stk_trans` a 
                INNER JOIN  backend_stktake.set_bin b 
                ON a.`BIN_ID`=b.`BIN_NO` 
                WHERE a.trans_guid='$trans_guid'
                AND a.`Itemcode`='$itemcode'
                GROUP BY b.`Location`,a.itemcode) n 
                ON m.`Itemcode`=n.itemcode SET m.stk_qty=n.sum_qty 
                WHERE m.trans_guid='$trans_guid'
                AND m.`Itemcode`='$itemcode'");           
            $edit_stkqoh = $this->db->query("UPDATE backend_stktake.stk_qoh SET Stk_Variance=stk_qty-qoh 
                WHERE trans_guid='$trans_guid' AND itemcode='$itemcode'");
        }
                $browser_id = $_SERVER["HTTP_USER_AGENT"];
                if(strpos($browser_id,"Windows CE"))
                    {
                        $this->load->view('WinCe/header');
                        $this->load->view('WinCe/stktake/scan_item');
                    }
                else
                    {
                        $this->load->view('header');
                        $this->load->view('stktake/scan_item');
                        $this->load->view('footer');
                    }    
        }
        else
        {
        redirect('main_controller');
        }
    }

    public function send_print()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {
            $sublocation = $_SESSION['sublocation'];
            $trans_guid = $_SESSION['trans_guid'];
            $bin_ID = $_SESSION['bin_ID'];
            $user_ID = $_SESSION['user_ID'];
            $send_print = $this->db->query("update backend_stktake.stk_trans set send_print = '1', send_print_sublocation = '$sublocation' where  trans_guid = (SELECT trans_guid FROM backend_stktake.set_date WHERE status_closed=0) AND bin_id='$bin_ID'");
            redirect('stktake_controller/scan_item?bin_ID='.$bin_ID."&user_ID=".$user_ID);
        }
        else
        {
            redirect('main_controller');
        }
    }
    
} // DO NOT END BEFORE HERE
?>