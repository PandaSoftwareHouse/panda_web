<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class general_scan_controller extends CI_Controller {
    
    public function __construct()
	{
		parent::__construct();
        $this->load->model('general_scan_model');
        $this->load->model('adjout_model');
        $this->load->model('adjin_model');
        $this->load->model('IBT_model');
        $this->load->model('PO_model');
        $this->load->library(array('session'));
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper(array('form','url'));
        $this->load->helper('html');
        $this->load->database();
        $this->load->library('form_validation');
	}
    // 2017-01-20

    public function scan_item()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {
            //$this->session->set_flashdata($get_weight,$get_price);
            $_SESSION['get_weight'] = '';
            $_SESSION['get_price'] = '';
            $_SESSION['itemcode'] = '';
            $_SESSION['barcode'] = '';

            
            $acc_code = $_REQUEST['acc_code'];
            $web_guid = $_REQUEST['web_guid'];
            $_module = $this->general_scan_model->checkModule($web_guid);
            $mod =  $_module->row('module_desc');

            if ($mod == 'PO' && $acc_code == '')
            {
                $acc_code = $_REQUEST['acc_code'];
                $web_guid = $_REQUEST['web_guid'];
                $mod = $_REQUEST['module_desc'];
            }
            elseif ($web_guid == '')
            {
                $web_guid = $_REQUEST['web_guid'];
            };
                if ($mod == 'PO')
                {
                    $back = site_url('PO_controller/item_in_po?web_guid='.$web_guid.'&acc_code='.$acc_code);
                }
                elseif ($mod == 'Sales Order')
                {
                    $back = site_url('SO_controller/item_in_so?web_guid='.$web_guid.'&acc_code='.$acc_code);
                }
                elseif ($mod == 'IBT Req')
                {
                    $back = site_url('IBT_controller/item_in_IBT?web_guid='.$web_guid);
                }
                elseif ($mod == 'Adjust-In')
                {
                    $back = site_url('adjin_controller/itemlist?web_guid='.$web_guid);
                }
                elseif ($mod == 'Adjust-Out')
                {
                    $back = site_url('adjout_controller/itemlist?web_guid='.$web_guid);
                }
                elseif ($mod == 'POS')
                {
                    $back = site_url('Mpos_controller/itemlist?web_guid='.$web_guid);
                }
                elseif ($mod == 'Simple SO')
                {
                    $back = site_url('simpleso_controller/itemlist?web_guid='.$web_guid);
                }
                else
                {
                    $back = site_url('main_controller');
                }
            $acc_code_Data = array(
                'acc_code' => $acc_code
                ,'web_guid' => $web_guid
                , 'module_desc'=> $mod
                // , 'sold_by_weight' => $sold_by_weight
                                );
            $this->session->set_userdata($acc_code_Data);
            
             $data = array (
                'module_desc' => $this->general_scan_model->checkModule($web_guid),
                'back' => $back,
                );

            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {
                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/general/scan_item', $data);
                }
            else
                {

                    
                    $this->load->view('header');
                    $this->load->view('general/scan_item', $data);
                    $this->load->view('footer');
            
                }   
        }  
        else
        {
           redirect('main_controller');
        } 
    }


    public function scan_itemresult()
    {
        
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {
            if ($this->input->post('barcode') != '')
            {$barcode = $this->input->post('barcode');
            }
            else
            {
                $web_c_guid = $_REQUEST['web_c_guid'];
                $barcode = '0';
            }


            if ($_SESSION['web_guid'] != '')
            { $web_guid = $_SESSION['web_guid']; }
            else
            {
                $web_guid = $_REQUEST['web_guid'];
            }

            if ($this->input->post('module_desc') != '')
            {$module = $this->input->post('module_desc');}
            else
            {
                $module1 = $this->general_scan_model->checkModule($web_guid);
                $module = $module1->row('module_desc');
            }

            $acc_code_Data = array(
                'module_desc'=> $module );
            $this->session->set_userdata($acc_code_Data);
            // check if need decode
            $barcode_type1 = $this->general_scan_model->check_itemmaster_all($barcode);
            if($barcode_type1-> num_rows() > 0)
            {
                foreach($barcode_type1->result() as $row)
                {
                    $barcode_type = $row->barcodetype;
                    $getsellingprice = $row->sellingprice;
                    $getsoldbyweight = $row->soldbyweight;
                    $get_weight = '';
                }
            }
            else if ($barcode_type1-> num_rows() == 0 )
            {
                 $barcode_type2 = $this->general_scan_model->check_itemmaster_18D($barcode);
                                 if($barcode_type2-> num_rows() > 0 )
                                {
                                    foreach($barcode_type2->result() as $row)
                                    {
                                        $barcode_type = $row->barcodetype;
                                        $getsellingprice = $row->sellingprice;
                                        $getsoldbyweight = $row->soldbyweight;
                                    }
                                 }// end barcodetype2
                                 else
                                 {
                                    $barcode_type = '';
                                 }

                $eighteenD = $this->general_scan_model->check_decode($module);
                if ($eighteenD->num_rows() != 0)
                {
                    if($barcode != '0')
                    {
                        foreach($eighteenD->result() as $row)
                        {
                        $weight_type_code               =  $row->weight_type_code;
                        $weight_capture_price           =  $row->weight_capture_price;
                        $weight_bar_pos_start           =  $row->weight_bar_pos_start;
                        $weight_bar_pos_count           =  $row->weight_bar_pos_count;
                        $weight_capture_factor          =  $row->weight_capture_factor;
                        $weight_capture_weight          =  $row->weight_capture_weight;
                        $weight_capture_pos_start       =  $row->weight_capture_pos_start;
                        $weight_capture_pos_count       =  $row->weight_capture_pos_count;
                        $weight_capture_weight_type     =  $row->weight_capture_weight_type;
                        $weight_capture_price_factor    =  $row->weight_capture_price_factor;
                        $weight_capture_price_pos_start =  $row->weight_capture_price_pos_start;
                        $weight_capture_price_pos_count =  $row->weight_capture_price_pos_count;
              

                        }
                        if ($weight_capture_weight == 1)
                        {
                            if($weight_capture_weight_type == 'actual weight')
                            {
                                if($barcode_type == 'Q') // sold by qty
                                {
                                $get_weight = substr($barcode, 
                                    $weight_capture_pos_start-1
                                    , $weight_capture_pos_count);

                                }
                                else // sold by weight
                                {
                                $get_weight = substr($barcode,$weight_capture_pos_start-1
                                            , $weight_capture_pos_count)/
                                            $weight_capture_factor;
                                }
                            }
                            else
                            {
                            $get_weight = (substr($barcode, $weight_capture_pos_start-1
                                        , $weight_capture_pos_count)/
                                        $weight_capture_factor) 
                           /* /$getsellingprice;*/ ;
                            } // end actual weight

                            $get_weight = round($get_weight,3);

                        }

                        if($weight_capture_price == 1)
                        {
                        $get_price = substr($barcode, $weight_capture_price_pos_start-1,
                            $weight_capture_price_pos_count)/
                            $weight_capture_price_factor;
                        }
                        $get_price = round($get_price,3);

                        $temp_weight_price = array(
                                    'get_weight' =>$get_weight,
                                    'get_price' => $get_price,
                                    );
                                    $this->session->set_userdata($temp_weight_price); 

 // force to find itemcode and truncate the barcode to get the front part
                       if ( strlen($barcode) == '18')
                                   {
                                       /*$_barcode = substr($barcode,0,-11);*/
                                       $_barcode = substr($barcode, $weight_bar_pos_start-1,$weight_bar_pos_count);
                                       $barcode = $_barcode;
                                   }
                        else if ( strlen($barcode) == '13')
                                   {
                                       /*$_barcode = substr($barcode,0,-6);*/
                                        $_barcode = substr($barcode, $weight_bar_pos_start-1,$weight_bar_pos_count);
                                       $barcode = $_barcode;
                                   }
                    }// end if checking barcode = 0
                    else
                    {
                         $web_guid = $_REQUEST['web_guid'];
                         $web_c_guid = $_REQUEST['web_c_guid'];
                         $_module = $this->general_scan_model->checkModule($web_guid);
                         $mod =  $_module->row('module_desc');
                         $acc_code_Data = array(
                            'module_desc'=> $mod,
                            'web_guid'=>$web_guid,
                            'web_c_guid'=>$web_c_guid);
                         $this->session->set_userdata($acc_code_Data);
                    }
                } // end 18D num_rows != 0
            } // end elseif num_rows() == 0
            else
            {
                echo 'Please check barcode type and barcode. Please close and reopen browser.';
            }

            // start sorting based on modules
            if ($module != 'PO')
            {
                    if ($this->input->post('barcode') != "")
                    {      

                    $check = $this->general_scan_model->check_guid($barcode);
                    $web_c_guid = $check->row('web_c_guid');
                    $web_guid = $check->row('web_guid');
                    $check_im = $this->general_scan_model->check_itemcode($barcode);
                    $itemcode = $check_im->row('itemcode');

                            if($check->num_rows() == 0 && $check_im->num_rows()!= 0)
                                {
                                    $data['itemresult'] = $itemcode1 = $this->adjout_model->itemresult_new($barcode);
                                    $itemcode =  $itemcode1->row('itemcode');
                                    $data['itemQOH'] = $this->adjout_model->itemQOH($itemcode);
                                    $data['itemQty']=$this->adjout_model->itemQty($itemcode);
                                    $data['module']= $module;

                                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                                    if(strpos($browser_id,"Windows CE"))
                                        {
                                            $this->load->view('WinCe/header');
                                            $this->load->view('WinCe/general/scan_itemresult', $data);
                                        }
                                    else
                                        {
                                            $this->load->view('header');
                                            $this->load->view('general/scan_itemresult', $data);
                                            $this->load->view('footer'); 
                                        }    
                
                                }// end check num rows == 0      
                            elseif ($check->num_rows() != 0 && $check_im->num_rows()!= 0 && $get_weight == '')
                                {
                                     $user_ID_Data = array(
                                    'web_c_guid' =>$check->row('web_c_guid'),
                                     'barcode'=>$barcode,
                                     'itemcode'=>$itemcode,
                                     'acc_code'=>'',
                                    );
                    
                                    $this->session->set_userdata($user_ID_Data);
                                    $data['itemresult']= $itemcode2 = $this->adjout_model->itemresult_new($barcode);
                                    $itemcode =  $itemcode2->row('itemcode');
                                    $data['itemQOH']  = $this->adjout_model->itemQOH($itemcode);
                                    $data['itemQty'] = $this->adjout_model->itemQty($itemcode);
                                    $data['module']= $module;

                                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                                    if(strpos($browser_id,"Windows CE"))
                                        {
                                            $this->load->view('WinCe/header');
                                            $this->load->view('WinCe/general/edit_item_result', $data);
                                        }
                                    else
                                        {
                                            $this->load->view('header');
                                            $this->load->view('general/edit_item_result', $data);
                                            $this->load->view('footer');
                                        }

                                } // end else check numrows == 0
                            elseif ($check->num_rows() != 0 && $check_im->num_rows()!= 0 && $get_weight != '')
                                {
                                    $data['itemresult'] = $itemcode1 = $this->adjout_model->itemresult_new($barcode);
                                    $itemcode =  $itemcode1->row('itemcode');
                                    $data['itemQOH'] = $this->adjout_model->itemQOH($itemcode);
                                    $data['itemQty']=$this->adjout_model->itemQty($itemcode);
                                    $data['module']= $module;
                                    $acc_code = array (
                                        'acc_code'=> '');
                                     $this->session->set_userdata($acc_code);
                                    
                                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                                    if(strpos($browser_id,"Windows CE"))
                                        {
                                            $this->load->view('WinCe/header');
                                            $this->load->view('WinCe/general/scan_itemresult', $data);
                                        }
                                    else
                                        {
                                            $this->load->view('header');
                                            $this->load->view('general/scan_itemresult', $data);
                                            $this->load->view('footer');
                                        }    

                                 }
                            elseif($check->num_rows() == 0 && $check_im->num_rows() == 0)
                                {
                                     $this->session->set_flashdata('message', 'Barcode not Found');
                                  redirect('general_scan_controller/scan_item?web_guid='.$_SESSION['web_guid']."&acc_code=".$_SESSION['acc_code']);

                                }
                    }; // end if barcode exist or not 

                    // this is direct click description
                   if ($this->input->post('barcode') == "" && $_REQUEST['web_c_guid'] != '' )
                    {   
                        $_SESSION['web_c_guid']='';
                        $web_c_guid = $_REQUEST['web_c_guid'];
                        $check_c_guid = $this->adjout_model->edit_itemqty($web_c_guid);
                         $itemcode =  $check_c_guid->row('itemcode');
                         $barcode =  $check_c_guid->row('barcode');
                         $web_guid =  $check_c_guid->row('web_guid');
                         $acc_code_Data = array(
                            'web_guid'=>$web_guid,
                            'barcode'=>$barcode,
                            'web_c_guid'=>$web_c_guid,
                            'acc_code'=>'',);
                         $this->session->set_userdata($acc_code_Data);
                        if($check_c_guid -> num_rows() != 0)
                        {     
                    $data['itemresult'] = $this->adjout_model->itemresult_new($barcode,$web_c_guid);
                    $data['itemQOH'] = $this->adjout_model->itemQOH($itemcode);
                    $data['itemQty'] = $this->adjout_model->edit_itemqty($web_c_guid);
                    $data['module']= $module;
                    $this->general_scan_model->reloadbillamt($web_guid);
                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                    if(strpos($browser_id,"Windows CE"))
                        {

                            $this->load->view('WinCe/header');
                            $this->load->view('WinCe/general/edit_item_result', $data);
                        }
                    else
                        {

                            $this->load->view('header');
                            $this->load->view('general/edit_item_result', $data);
                            $this->load->view('footer');
                        }

                        }//  end check_c_guid num row
                    }; // end elseif edit_itemqty using web_c_guid
             } ;  // end $module == 'Adjust-Out' || 'Adjust-In' || 'Sales Order' || 'IBT req'

            if ($module == 'PO' )
            {
                if ($this->input->post('barcode') != "")
                    {      
                    $check = $this->general_scan_model->check_guid($barcode);
                        $web_c_guid = $check->row('web_c_guid');
                        $web_guid = $check->row('web_guid');
                        $acc_code = $check->row('acc_code');
                    $check_im = $this->general_scan_model->check_itemcode($barcode);
                        $itemcode = $check_im->row('itemcode');
                    if ($acc_code == '')
                    {
                        $check_acc = $this->general_scan_model->check_acc();
                        $acc_code = $check_acc->row('acc_code');
                        
                        $checkpoprice_method = $this->db->query("SELECT poprice_method from backend.supcus where code = '$acc_code'")->row('poprice_method');
                        if($checkpoprice_method != 'ILAST')
                        {
                            $check_sup= $this->general_scan_model->check_supplier($itemcode,$acc_code);
                            $check_itemmastersupcode = 'true';
                        }
                        else
                        {
                            $check_sup = $this->db->query("SELECT * from backend.itemmaster where itemcode = '$itemcode'");
                            $check_itemmastersupcode = 'false';
                        }
                    }
                    else
                    {
                    $checkpoprice_method = $this->db->query("SELECT poprice_method from backend.supcus where code = '$acc_code'")->row('poprice_method');
                        if($checkpoprice_method != 'ILAST')
                        {
                        $check_sup= $this->general_scan_model->check_supplier($itemcode,$acc_code);  
                            $check_itemmastersupcode = 'true';
                        }
                        else
                        {
                            $check_sup = $this->db->query("SELECT * from backend.itemmaster where itemcode = '$itemcode'");
                            $check_itemmastersupcode = 'false';
                        }  
                    }
                        if($check->num_rows() == 0 && $check_im->num_rows()!= 0 && $check_sup-> num_rows() != 0)
                               {
                              // echo 'PO condition 1' new record;     
                               $data['itemresult'] = $itemcode1 = $this->PO_model->itemresult_po($barcode,$check_itemmastersupcode);
                               //echo $this->db->last_query();die;
                               $itemcode =  $itemcode1->row('itemcode');
                               $data['itemQOH'] = $this->PO_model->itemQOH($itemcode);
                               $data['itemQty']=$this->PO_model->itemQty($barcode, $web_guid);
                               $data['module']= $module;

                               $browser_id = $_SERVER["HTTP_USER_AGENT"];
                               if(strpos($browser_id,"Windows CE"))
                                {
                                    $this->load->view('WinCe/header');
                                    $this->load->view('WinCe/po/scan_itemresult', $data);
                                }
                               else
                                {
                                    $this->load->view('header');
                                    $this->load->view('po/scan_itemresult', $data);
                                    $this->load->view('footer');
                                } 
                               }// end check num rows == 0      
                        elseif($check->num_rows() != 0 && $check_im->num_rows()!= 0 && $check_sup->num_rows() != 0 && $get_weight == '')
                               {
                                // force web_c_guid to become session from $check
                                $user_ID_Data = array(
                               'web_c_guid' =>$check->row('web_c_guid')
                               ,'web_guid' =>$check->row('web_guid')
                               , 'acc_code' =>$check->row('acc_code')
                               );
                                $this->session->set_userdata($user_ID_Data);
                               // echo 'PO condition 2';
                                $data['itemresult']= $itemcode2 = $this->PO_model->itemresult_po($barcode, $check_itemmastersupcode);

                                $itemcode =  $itemcode2->row('itemcode');
                                $sellingprice1 = $this->PO_model->itemQty($barcode, $web_guid);
                                $data['sellingprice'] = $sellingprice1->row("sellingprice");
                                $data['itemQOH']  = $this->PO_model->itemQOH($itemcode);
                                $data['itemQty'] = $this->PO_model->itemQty($barcode, $web_guid);
                                $data['module']= $module;

                                $browser_id = $_SERVER["HTTP_USER_AGENT"];
                                if(strpos($browser_id,"Windows CE"))
                                    {
                                      $this->load->view('WinCe/header');
                                      $this->load->view('WinCe/po/edit_itemresult', $data, $web_c_guid);    
                                    }
                                else
                                    {
                                        $this->load->view('header');
                                        $this->load->view('po/edit_itemresult', $data, $web_c_guid);
                                        $this->load->view('footer');
                                    }
                                }
                                 // end else check numrows == 0

                        elseif ($check->num_rows() != 0 && $check_im->num_rows()!= 0 && $check_sup-> num_rows() != 0 && $get_weight != '')
                        {
                            $data['itemresult'] = $itemcode1 = $this->PO_model->itemresult_po($barcode, $check_itemmastersupcode);
                            
                            $itemcode =  $itemcode1->row('itemcode');
                            $data['itemQOH'] = $this->PO_model->itemQOH($itemcode);
                            $data['itemQty']= $this->PO_model->itemQty($barcode, $web_guid);
                            $data['module']= $module;
                            $user_ID_Data = array(
                                'acc_code' =>$check->row('acc_code')
                               );
                                $this->session->set_userdata($user_ID_Data);
                            $browser_id = $_SERVER["HTTP_USER_AGENT"];
                            if(strpos($browser_id,"Windows CE"))
                                {
                                    $this->load->view('WinCe/header');
                                    $this->load->view('WinCe/po/scan_itemresult', $data);
                                }
                            else
                                {
                                    $this->load->view('header');
                                    $this->load->view('po/scan_itemresult', $data);
                                    $this->load->view('footer');
                                }    
                        }
                        /*elseif($check->num_rows() == 0 && $check_im->num_rows() == 0 && $check_sup-> num_rows() == 0)*/
                        else {

                                $browser_id = $_SERVER["HTTP_USER_AGENT"];
                                if(strpos($browser_id,"Windows CE"))
                                    {
                                        $this->load->view('WinCe/header');
                                        $this->load->view('WinCe/po/norecord');
                                    }
                                else
                                    {
                                          
                                        $this->load->view('header');
                                        $this->load->view('po/norecord');
                                        $this->load->view('footer');
                                    }   
                            }
                        
                    } // end if barcode exist or not
                    elseif ($this->PO_model->edit_itemqty($web_c_guid) != '')
                    {
                        $check_c_guid = $this->PO_model->edit_itemqty($web_c_guid);
                         foreach ($check_c_guid->result() as $row)
                            {
                                $barcode =  $row->barcode;
                                $web_c_guid = $row->web_c_guid;
                                $itemcode = $row->itemcode;
                            }
                        if($check_c_guid -> num_rows() != 0)
                        {     
                    $data['itemresult'] = $this->PO_model->itemresult($barcode,$web_c_guid);
                    $data['itemQOH'] = $this->PO_model->itemQOH($itemcode);
                    $data['itemQty'] = $this->PO_model->edit_itemqty($web_c_guid);
                    $data['module']= $module;
     
                    $this->general_scan_model->reloadbillamt($web_guid);

                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                    if(strpos($browser_id,"Windows CE"))
                        {
                            $this->load->view('WinCe/header');
                            $this->load->view('WinCe/po/edit_itemresult', $data);
                        }
                    else
                        {
                            $this->load->view('header');
                            $this->load->view('po/edit_itemresult', $data);
                            $this->load->view('footer');
                        }   
                        } // end check_c_guid num row
                        else
                        {
                           /* echo "Web Guid for item Not Found. Please close and reopen browser.";*/
                        }
                    } // end elseif edit_itemqty using web_c_guid
            }  // end PO mode
            else
            {
                /*echo "If blank page... check here.. 
                Module Session Timeout, return module == null. Please close and reopen browser.";*/
            };
        } // end if login = true for scan item result
    } // end function scan_itemresult()

        public function add_qty()
        {
            if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
            {

            $web_c_guid = $this->input->post('web_c_guid');
            $web_guid = $this->input->post('web_guid');
            $itemcode = $this->input->post('itemcode');
            $description = $this->input->post('description');
            $sellingprice = $this->input->post('sellingprice');
            $foc_qty = $this->input->post('foc_qty');
            $barcode = $this->input->post('barcode');
            $SinglePackQOH = $this->input->post('SinglePackQOH');
            $iqty = $this->input->post('iqty');
            $defaultqty = $this->input->post('defaultqty');
            $soldbyweight = $this->input->post('soldbyweight');
            $qty = $this->input->post('qty');
            $remark = addslashes($this->input->post('remark'));

            $use_cost = $this->db->query("SELECT lastcost from itemmaster where itemcode = '$itemcode' ")->row('lastcost');
            
            if($_SESSION['module_desc'] == 'PO' || $_SESSION['module_desc'] == 'IBT Req' || $_SESSION['module_desc'] == 'Adjust-In' || $_SESSION['module_desc'] == 'Adjust-Out' )
            {
            	$_amount = ($defaultqty+$qty+$iqty)*$use_cost;
            }
            else
            {
            	$_amount = ($defaultqty+$qty+$iqty)*$sellingprice;
        	}

            $totalqty  = $foc_qty+$iqty+$defaultqty;

            $result = $this->PO_model->add_qty($web_c_guid,$web_guid,$itemcode,$description,$sellingprice,$foc_qty,$barcode,$SinglePackQOH,$remark,$totalqty,$_amount,$soldbyweight);

                     if ($_SESSION['module_desc'] == 'PO')
                {
                    $back = site_url('PO_controller/item_in_po?web_guid='.$_SESSION['web_guid'].'&acc_code='.$_SESSION['acc_code']);
                }
                elseif ($_SESSION['module_desc'] == 'Sales Order')
                {
                    $back = site_url('SO_controller/item_in_so?web_guid='.$_SESSION['web_guid']);
                }
                elseif ($_SESSION['module_desc'] == 'IBT Req')
                {
                    $back = site_url('IBT_controller/item_in_IBT?web_guid='.$_SESSION['web_guid']);
                }
                elseif ($_SESSION['module_desc'] == 'Adjust-In')
                {
                    $back = site_url('adjin_controller/itemlist?web_guid='.$_SESSION['web_guid']);
                }
                elseif ($_SESSION['module_desc'] == 'Adjust-Out')
                {
                    $back = site_url('adjout_controller/itemlist?web_guid='.$_SESSION['web_guid']);
                }
                elseif ($_SESSION['module_desc'] == 'POS')
                {
                    $back = site_url('Mpos_controller/itemlist?web_guid='.$_SESSION['web_guid']);
                }
                elseif ($_SESSION['module_desc'] == 'Simple SO')
                {
                    $back = site_url('simpleso_controller/itemlist?web_guid='.$_SESSION['web_guid']);
                }
                else
                {
                    $back = site_url('main_controller/home');
                }

                $data = array (
                    'web_guid' => $this->general_scan_model->reloadmodel($web_guid),
                    'module_desc' => $this->general_scan_model->checkModule($web_guid),
                    'back' => $back,
                    );

                    $this->general_scan_model->reloadbillamt($web_guid);
                    $_SESSION['get_weight'] = '';
                    $_SESSION['get_price'] = '';

                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                    if(strpos($browser_id,"Windows CE"))
                        {
                             $this->load->view('WinCe/header');
                             $this->load->view('WinCe/general/scan_item',$data);
                        }
                    else
                        {
                             $this->load->view('header');
                             $this->load->view('general/scan_item',$data);
                             $this->load->view('footer');
                        }    
                   
            }
            else
            {
                redirect('main_controller');
            }
    } // end public function add_qty()


    public function update_qty()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {

        $web_c_guid = $this->input->post('web_c_guid');
        $itemcode = $this->input->post('itemcode');
        $description = $this->input->post('description');
        $sellingprice = $this->input->post('sellingprice');
        $foc_qty = $this->input->post('foc_qty');
        $barcode = $this->input->post('barcode');
        $SinglePackQOH = $this->input->post('SinglePackQOH');
        $iqty = $this->input->post('iqty');
        $defaultqty = $this->input->post('defaultqty');
        $web_guid = $this->input->post('web_guid');
        $acc_code = $this->input->post('acc_code');
        $qty = $this->input->post('qty');
        $remark = addslashes($this->input->post('remark'));
        


        $use_cost = $this->db->query("SELECT lastcost from itemmaster where itemcode = '$itemcode' ")->row('lastcost');
            
            if($_SESSION['module_desc'] == 'PO' || $_SESSION['module_desc'] == 'IBT Req' || $_SESSION['module_desc'] == 'Adjust-In' || $_SESSION['module_desc'] == 'Adjust-Out' )
            {
            	$_amount = ($defaultqty+$qty+$iqty)*$use_cost;
            }
            else
            {
            	$_amount = ($defaultqty+$qty+$iqty)*$sellingprice;
        	}
        	
        /*$_amount = ($defaultqty+$qty+$iqty)*$sellingprice;*/
        $totalqty  = $foc_qty+$iqty+$defaultqty;
        

            $result = $this->PO_model->update_qty($web_c_guid,$itemcode,$description,$sellingprice,$foc_qty,$barcode,$SinglePackQOH,$remark,$totalqty,$_amount);

                if ($_SESSION['module_desc'] == 'PO')
                {
                    $back = site_url('PO_controller/item_in_po?web_guid='.$_SESSION['web_guid'].'&acc_code='.$acc_code);
                }
                elseif ($_SESSION['module_desc'] == 'Sales Order')
                {
                    $back = site_url('SO_controller/item_in_so?web_guid='.$_SESSION['web_guid']);
                }
                elseif ($_SESSION['module_desc'] == 'IBT Req')
                {
                    $back = site_url('IBT_controller/item_in_IBT?web_guid='.$_SESSION['web_guid']);
                }
                elseif ($_SESSION['module_desc'] == 'Adjust-In')
                {
                    $back = site_url('adjin_controller/itemlist?web_guid='.$_SESSION['web_guid']);
                }
                elseif ($_SESSION['module_desc'] == 'Adjust-Out')
                {
                    $back = site_url('adjout_controller/itemlist?web_guid='.$_SESSION['web_guid']);
                }
                 elseif ($_SESSION['module_desc'] == 'POS')
                {
                    $back = site_url('Mpos_controller/itemlist?web_guid='.$_SESSION['web_guid']);
                }
                elseif ($_SESSION['module_desc'] == 'Simple SO')
                {
                    $back = site_url('simpleso_controller/itemlist?web_guid='.$_SESSION['web_guid']);
                }
                else
                {
                    $back = site_url('main_controller/home');
                }

                $data = array (
                    'web_guid' => $this->general_scan_model->reloadmodel($web_guid),
                    'module_desc' => $this->general_scan_model->checkModule($web_guid),
                    'back' => $back,
                    );   
                $this->general_scan_model->reloadbillamt($web_guid);
                $browser_id = $_SERVER["HTTP_USER_AGENT"];
                if(strpos($browser_id,"Windows CE"))
                    {
                         $this->load->view('WinCe/header');
                         $this->load->view('WinCe/general/scan_item',$data);           
                    }
                else
                    {
                         $this->load->view('header');
                         $this->load->view('general/scan_item',$data);
                         $this->load->view('footer');
                    }    
        }
        else
        {
             redirect('main_controller');
        }
    } // end public function edit qty()

    



}
?>