<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dnbatch_controller extends CI_Controller {
    
    public function __construct()
	{
		parent::__construct();
        $this->load->model('dnbatch_model');
        $this->load->model('general_scan_model');
        $this->load->library(array('session'));
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper(array('form','url'));
        $this->load->helper('html');
        $this->load->database();
        $this->load->library('form_validation');
	}

    public function main()
    {
        if($this->session->userdata('login') == false)
        {
            $data = array( 
                'result' => $this->db->query("SELECT * FROM dbnote_batch WHERE converted=0 AND canceled=0 
                 AND DATE(created_at)=DATE(NOW()) 
                 AND created_by='".$_SESSION['username']."'  ORDER BY created_at DESC"),
                );

            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {
                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/dnbatch/main', $data);
                }
            else
                {
                    $this->load->view('header');
                    $this->load->view('dnbatch/main', $data);
                    $this->load->view('footer');
                }    
        }
        else
        {
           redirect('main_controller');
        }
    }

    public function scan_supplier()
    {
        if($this->session->userdata('loginuser')== true)
        {
            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {
                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/dnbatch/scan_supplier');
                }
            else
                {
                    $this->load->view('header');
                    $this->load->view('dnbatch/scan_supplier');
                    $this->load->view('footer');
                }    
        }  
        else
        {
          redirect('main_controller');
        } 
    }

     public function scan_supresult()
    {
        
        if($this->session->userdata('loginuser')== true)
        {
            
            $check_supbarcode = $this->db->query("SELECT a.itemcode,a.barcode,a.bardesc, c.description,b.name,b.code FROM itembarcode a INNER JOIN itemmastersupcode b ON a.itemcode=b.itemcode INNER JOIN itemmaster c ON c.itemcode=b.itemcode WHERE barcode='".$this->input->post('barcode')."' GROUP BY b.code");

            if ($check_supbarcode->num_rows() == 1)
            {

            $data = array(
                'dnbatch_itemcode' => $check_supbarcode->row('itemcode'),
                'dnbatch_barcode' => $this->input->post('barcode'),
                'dnbatch_sup_code' => addslashes($check_supbarcode->row('code')),
                'dnbatch_sup_name' => addslashes($check_supbarcode->row('name')),
                'dnbatch_description' => addslashes($check_supbarcode->row('description')),
                );
            $this->session->set_userdata($data);
            redirect('dnbatch_controller/scan_supconfirm?sup_code='.$check_supbarcode->row('code'));
            }
            elseif ($check_supbarcode->num_rows() > 1)
            {

            $data = array(
                'dnbatch_itemcode' => $check_supbarcode->row('itemcode'),
                'dnbatch_barcode' => $this->input->post('barcode'),
                'dnbatch_description' => addslashes($check_supbarcode->row('description')),
                );
            $supplier_result = array (
                'result' => $this->db->query("SELECT a.itemcode,a.barcode,a.bardesc, c.description,b.name,b.code FROM itembarcode a INNER JOIN itemmastersupcode b ON a.itemcode=b.itemcode INNER JOIN itemmaster c ON c.itemcode=b.itemcode WHERE barcode='".$this->input->post('barcode')."' GROUP BY b.code"),
                );
            $this->session->set_userdata($data);

            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {
                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/dnbatch/scan_suplist', $supplier_result);
                }
            else
                {
                    $this->load->view('header');
                    $this->load->view('dnbatch/scan_suplist', $supplier_result);
                    $this->load->view('footer');
                }    

            }
            else 
            {   
                $this->session->set_flashdata('message', 'Supplier not found : '.$this->input->post('barcode'));
                $_SESSION['dnbatch_itemcode'] = '';
                $_SESSION['dnbatch_barcode'] = '';
                $_SESSION['dnbatch_sup_code'] = '';
                $_SESSION['dnbatch_sup_name'] = '';
                $_SESSION['dnbatch_description'] = '';
                redirect('dnbatch_controller/scan_supplier');
            }
        } 
        else
        {
           redirect('main_controller/home');
        } 
    }

    public function scan_supconfirm()
    {
        if($this->session->userdata('loginuser')== true)
        {
        $supdetail = $this->db->query("SELECT * FROM supcus WHERE TYPE= 'S' AND CODE = '".$_REQUEST['sup_code']."'");
        $data = array(
            'supdetail' => $supdetail,
            );
        $browser_id = $_SERVER["HTTP_USER_AGENT"];
        if(strpos($browser_id,"Windows CE"))
            {
                $this->load->view('WinCe/header');
                $this->load->view('WinCe/dnbatch/scan_supconfirm', $data);
            }
        else
            {
                $this->load->view('header');
                $this->load->view('dnbatch/scan_supconfirm', $data);
                $this->load->view('footer');
            }    
        }
        else
        {
            redirect('main_controller');
        }

    }

    public function create_batch()
    {
        if($this->session->userdata('loginuser')== true)
        {
        $supdetail = $this->db->query("SELECT code,name FROM supcus WHERE TYPE= 'S' AND CODE = '".$_REQUEST['sup_code']."'");
        $checkdate = $this->db->query("SELECT YEAR(NOW()) AS getYear,MONTH(NOW()) AS getMonth");
        $checkDNBAT = $this->db->query("SELECT * from sysrun where type='DNBAT'");

        if($checkDNBAT->num_rows() == 0)
        {
             $this->dnbatch_model->insertsysrun();
        };
        if($checkDNBAT->row('YYYY') != $checkdate->row('getYear') || $checkDNBAT->row('MM') != $checkdate->row('getMonth') )
        {
            $this->dnbatch_model->updatesysrun();
        };

        $this->dnbatch_model->updaterunningnum();
        $resultDNBAT = $this->db->query("SELECT * from sysrun where type='DNBAT'");

        $data = array(
            'batch_no' =>$this->db->query("SELECT CONCAT(Code, YYYY, LPAD(MM,2,0) ,LPAD(CurrentNo, NoDigit, 0)) as batch_no FROM sysrun WHERE TYPE = 'DNBAT'")->row('batch_no') ,
            'dnbatch_sup_code' => $supdetail->row('code'),
            'dnbatch_sup_name' => addslashes($supdetail->row('name')),

            );
        $this->session->set_userdata($data);
        $this->dnbatch_model->insert_batchno();

        $browser_id = $_SERVER["HTTP_USER_AGENT"];
        if(strpos($browser_id,"Windows CE"))
            {
                $this->load->view('WinCe/header');
                redirect("dnbatch_controller/itemlist?batch_no=".$_SESSION['batch_no']);
            }
        else
            {
                $this->load->view('header');
                redirect("dnbatch_controller/itemlist?batch_no=".$_SESSION['batch_no']);
                $this->load->view('footer');
            }    
        }
        else
        {
            redirect('main_controller');
        }
    }

    public function itemlist()
    {
        if($this->session->userdata('loginuser')== true)
        {
        $checkbatch = $this->db->query("SELECT * from dbnote_batch WHERE batch_no='".$_REQUEST['batch_no']."'");

        $data = array(
            'result' => $this->db->query("SELECT qty, description, dbnote_guid, dbnote_c_guid FROM dbnote_batch_c WHERE dbnote_guid='".$checkbatch->row('dbnote_guid')."' GROUP BY created_at DESC"),
            );
        $session = array (
            'dbnote_guid' => $checkbatch->row('dbnote_guid'),
            'batch_no' => $checkbatch->row('batch_no'),
            'sup_code' => $checkbatch->row('sup_code'),
            'sup_name' => addslashes($checkbatch->row('sup_name')),
            );
        $this->session->set_userdata($session);

        $browser_id = $_SERVER["HTTP_USER_AGENT"];
        if(strpos($browser_id,"Windows CE"))
            {
                $this->load->view('WinCe/header');
                $this->load->view('WinCe/dnbatch/itemlist', $data);
            }
        else
            {
                $this->load->view('header');
                $this->load->view('dnbatch/itemlist', $data);
                $this->load->view('footer');
            }    
        }
        else
        {
            redirect('main_controller');
        }
    }

    
    public function scan_item()
    {
        if($this->session->userdata('loginuser')== true)
        {
            
            $batch_no = $_SESSION['batch_no'];

            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {
                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/dnbatch/scan_item');
                }
            else
                {
                    $this->load->view('header');
                    $this->load->view('dnbatch/scan_item');
                    $this->load->view('footer');
                }    
        }  
        else
        {
          redirect('main_controller');
        } 
    }

    public function scan_itemresult()
    {
        
        if($this->session->userdata('loginuser')== true)
        {
            if ($this->input->post('barcode') != '')
            {
                $barcode = $this->input->post('barcode');
            }
            else
            {
                $barcode = $this->db->query("SELECT scan_barcode from dbnote_batch_c where dbnote_c_guid = '".$_REQUEST['dbnote_c_guid']."'")->row('scan_barcode');
            }
            $check_barcode = $this->db->query("SELECT a.itemcode,a.barcode,a.bardesc, c.description,b.name,b.code FROM itembarcode a INNER JOIN itemmastersupcode b ON a.itemcode=b.itemcode INNER JOIN itemmaster c ON c.itemcode=b.itemcode WHERE barcode='$barcode' AND b.code='".$_SESSION['sup_code']."' GROUP BY b.code");
            $sup_name = $this->db->query("SELECT a.itemcode,a.barcode,a.bardesc, c.description,b.name,b.code FROM itembarcode a INNER JOIN itemmastersupcode b ON a.itemcode=b.itemcode INNER JOIN itemmaster c ON c.itemcode=b.itemcode WHERE barcode='$barcode' AND b.code='".$_SESSION['sup_code']."' GROUP BY b.code")->row('name');
            $qty_default = $this->db->query("SELECT qty FROM dbnote_batch_c where scan_barcode = '$barcode' AND dbnote_guid = '".$_SESSION['dbnote_guid']."'");
            if ($check_barcode->num_rows() > 0)
            {

            $data = array(
                'item' => $check_barcode,
                'qty'=> $qty_default,
                );

            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {
                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/dnbatch/scan_itemresult', $data);
                }
            else
                {
                    $this->load->view('header');
                    $this->load->view('dnbatch/scan_itemresult', $data);
                    $this->load->view('footer');
                }    
            }
            else 
            {   
                $this->session->set_flashdata('message', 'Barcode '.$barcode.' not found in supplier : '.$sup_name);
                redirect('Dnbatch_controller/scan_item');
            }
        } 
        else
        {
           redirect('main_controller/home');
        } 
    } 

    public function add_qty()
    {
        if($this->session->userdata('loginuser')== true)
        {
        $itemcode = $this->input->post('itemcode');
        $barcode = $this->input->post('barcode');
        $iqty = $this->input->post('iqty');
        $dbnote_c_guid = $this->db->query("SELECT dbnote_c_guid FROM dbnote_batch_c where scan_barcode = '$barcode' AND dbnote_guid = '".$_SESSION['dbnote_guid']."'")->row('dbnote_c_guid');

        if ($dbnote_c_guid != '')
        {
        $this->dnbatch_model->update_qty($dbnote_c_guid,$iqty);
        $this->dnbatch_model->update_dbnote_c();
        }
        else
        {
        $this->dnbatch_model->insert_dbnote_c($itemcode, $iqty, $barcode);
        $this->dnbatch_model->update_dbnote_c();            
        }

        $browser_id = $_SERVER["HTTP_USER_AGENT"];
        if(strpos($browser_id,"Windows CE"))
            {
                $this->load->view('WinCe/header');
                $this->load->view('WinCe/dnbatch/scan_item');
            }
        else
            {
                $this->load->view('header');
                $this->load->view('dnbatch/scan_item');
                $this->load->view('footer');
            }    
        }
        else
        {
           redirect('main_controller');
        }
    }

     public function delete_batch()
    {
        if($this->session->userdata('loginuser')== true)
        {
            $dbnote_guid = $_REQUEST['dbnote_guid'];
            $deletem = $this->db->query("DELETE FROM dbnote_batch where dbnote_guid = '$dbnote_guid'");
            $deletec = $this->db->query("DELETE FROM dbnote_batch_c where dbnote_guid = '$dbnote_guid'");
            redirect('Dnbatch_controller/main');
        }
         else
        {
           redirect('main_controller');
        } 
    }

         public function delete_item()
    {
        if($this->session->userdata('loginuser')== true)
        {
            $dbnote_c_guid = $_REQUEST['dbnote_c_guid'];
            $dbnote_guid = $_REQUEST['dbnote_guid'];
            $batch_no = $this->db->query("SELECT batch_no from dbnote_batch where dbnote_guid = '$dbnote_guid'")->row('batch_no');
            $deletec = $this->db->query("DELETE FROM dbnote_batch_c where dbnote_c_guid = '$dbnote_c_guid'");
            redirect('Dnbatch_controller/itemlist?batch_no='.$batch_no);
        }
         else
        {
           redirect('main_controller');
        } 
    }


    public function print_job()
    {
         if($this->session->userdata('loginuser')== true)
        {
            $printed = $this->db->query("UPDATE dbnote_batch SET send_print='1' WHERE dbnote_guid='".$_SESSION['dbnote_guid']."'");
            redirect('Dnbatch_controller/itemlist?batch_no='.$_SESSION['batch_no']);
        }
    }

    public function search_refno()
    {
        if($this->session->userdata('loginuser')== true)
        {
            $batch_no = $this->input->post('batch_no');
            $checkrecord = $this->db->query("SELECT * FROM dbnote_batch where batch_no ='$batch_no'");
            if($checkrecord->num_rows() > 0)
            {
                $data = array ( 
                    'result' => $checkrecord,
                    );

                $browser_id = $_SERVER["HTTP_USER_AGENT"];
                if(strpos($browser_id,"Windows CE"))
                    {
                        $this->load->view('WinCe/header');
                        redirect("dnbatch_controller/itemlist?batch_no=$batch_no");
                    }
                else
                    {
                        $this->load->view('header');
                        redirect("dnbatch_controller/itemlist?batch_no=$batch_no");
                        $this->load->view('footer');
                    }    
            }
            else
            {
                $this->session->set_flashdata('message', 'Batch No. not found :'.$this->input->post('batch_no'));
                $data = array( 
                'result' => $this->db->query("SELECT * FROM dbnote_batch WHERE converted=0 AND canceled=0 
                 AND DATE(created_at)=DATE(NOW()) 
                 AND created_by='".$_SESSION['username']."'  ORDER BY created_at DESC"),
                );

                $browser_id = $_SERVER["HTTP_USER_AGENT"];
                if(strpos($browser_id,"Windows CE"))
                    {
                        $this->load->view('WinCe/header');
                        $this->load->view('WinCe/dnbatch/main', $data);
                    }
                else
                    {
                        $this->load->view('header');
                        $this->load->view('dnbatch/main', $data);
                        $this->load->view('footer');
                    }    
            }
        }

    }

}
?>