<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once BASEPATH.'core/CodeIgniter.php';
class main_controller extends CI_Controller {
    
    public function __construct()
	{
		parent::__construct();
        $this->load->model('Main_Model');
        $this->load->library(array('session'));
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper(array('form','url'));
        $this->load->helper('html');
        $this->load->database();
        $this->load->library('form_validation');

	}
    
	
	public function index()
	{
        $this->load->database();
        $this->load->model('Main_Model'); 
        $data['location']=$this->Main_Model->location();

        $browser_id = $_SERVER["HTTP_USER_AGENT"];
        if(strpos($browser_id,"Windows CE"))
            {
                $this->load->view('WinCe/header');
                $this->load->view('WinCe/index',$data);
            }
        else
            {
                $this->load->view('header');
                $this->load->view('index', $data);
                $this->load->view('footer');   
            }       
		
	}


    public function login_form()
    {
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('userpass', 'Password', 'trim|required');
        $this->form_validation->set_rules('location', 'Location', 'trim|required');

        if($this->form_validation->run() == FALSE)
        {
            $this->load->database();
            $this->load->model('Main_Model'); 
            $data['location']=$this->Main_Model->location();

            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {

                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/index',$data);
                
                }   
                
            else
                {
                    $this->load->view('header');
                    $this->load->view('index', $data);
                    $this->load->view('footer');
                }
        }
        else
        {   
            $username = $this->input->post('username');
            $userpass = $this->input->post('userpass');
            $location = $this->input->post('location');
            
                $result  = $this->Main_Model->login_data($username, $userpass);
                if($result > 0)
                {
                    $query = $this->db->query("SELECT location from backend_warehouse.set_sublocation where sublocation='$location'");
                    $locationSession = $query->row('location');

                    $query1 = $this->db->query("SELECT locgroup_branch from backend.companyprofile ");
                    $locationGroup = $query1->row('locgroup_branch');
                    
                    //set the session variables
                    $sessiondata = array(
                              
                        'username' => $username,
                        'userpass' => $userpass,
                        'sub_location' => $location,
                        'location' => $locationSession,
                        'loc_group' => $locationGroup,
                        'loginuser' => TRUE
                             
                    );
                         
                    $this->session->set_userdata($sessiondata);
                    redirect("main_controller/home", $sessiondata);
                    echo "<script> alert('succesfully loged in');</script>";     
                }
                else
                {
                    echo "<script> alert('Incorrect username or password');</script>";
                    $this->load->database();
                    $this->load->model('Main_Model'); 
                    $data['location']=$this->Main_Model->location();

                    $browser_id = $_SERVER["HTTP_USER_AGENT"];
                    if(strpos($browser_id,"Windows CE"))
                        {

                            $this->load->view('WinCe/header');
                            $this->load->view('WinCe/index',$data);
                            
                        }
                    else 
                    {   
                        $this->load->view('header');
                        $this->load->view('index', $data);
                        $this->load->view('footer');
                    }    
                }
            
            
        }
    }


    public function login_form2()
    {
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('userpass', 'Password', 'trim|required');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->load->view('header');
            $this->load->view('index');
            $this->load->view('footer');
        }
        else
        {   
            $username = $this->input->post('username');
            $userpass = $this->input->post('userpass');
            
            if ($this->input->post('login') == "Login")
            {
                $result  = $this->Main_Model->login_data($username, $userpass);
                if($result > 0)
                {
                    $query = $this->db->query("SELECT location from backend_warehouse.set_sublocation where sublocation='$location'");
                    $locationSession = $query->row('location');

                    $query1 = $this->db->query("SELECT locgroup_branch from backend.companyprofile ");
                    $locationGroup = $query1->row('locgroup_branch');
                    
                    //set the session variables
                    $sessiondata = array(
                              
                        'username' => $username,
                        'userpass' => $userpass,
                        'sub_location' => $location,
                        'location' => $locationSession,
                        'loc_group' => $locationGroup,
                        'loginuser' => TRUE
                             
                    );
                         
                    $this->session->set_userdata($sessiondata);
                    redirect("main_controller/home", $sessiondata);
                    echo "<script> alert('succesfully loged in');</script>";     
                }
                else
                {
                    echo "<script> alert('cannot loged in');</script>";
                    redirect('main_controller');

                }
            }
            
        }
    }


    public function home()
    {
        
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {
            redirect('logout_c/clearSession');
        }
        else
        {
            redirect('main_controller');
        }
    }

    public function homemenu()
    {
        
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {
            $this->load->database();
            $this->load->model('Main_Model');  
            $check_guid = $this->db->query("SELECT user_group_guid from backend_warehouse.set_user where user_name = '".$_SESSION['username']."'")->row('user_group_guid');

            $data = array (
                'user_group' => $this->db->query("SELECT user_name, user_group_guid from backend_warehouse.set_user where user_group_guid = '$check_guid' limit 1"),
                'menu' => $this->Main_Model->home_data(),
                );
            $browser_id = $_SERVER["HTTP_USER_AGENT"];
            if(strpos($browser_id,"Windows CE"))
                {
                    $this->load->view('WinCe/header');
                    $this->load->view('WinCe/home',$data);
                }
            else
                {
                    $this->load->view('header');
                    $this->load->view('home', $data);
                    $this->load->view('footer');
                }    
        }
        else
        {
            redirect('main_controller');
        }
    }

    public function confirm_post()
    {
        if ($_REQUEST['post_type'] =='trx_out')
        {
            $data = array(
                'title' => 'POST BATCH TRANSFER OUT',
                'content' => 'Post This Transaction: '.$_REQUEST['refno'],
                'back_button' => site_url('obatch_controller/post_scan'),
                'action' => site_url('main_controller/general_post?post_type=trx_out&trans_guid='.$_REQUEST['trans_guid'])
                );
        };

        if ($_REQUEST['post_type'] =='trx_rec_child')
        {
            $data = array(
                'title' => 'POST BATCH TRANSFER IN (CHILD)',
                'content' => 'Post This Transaction: '.$_REQUEST['refno'],
                'back_button' => site_url('rbatch_controller/scan_item'),
                'action' => site_url('main_controller/general_post?post_type=trx_rec_child&child_guid='.$_REQUEST['child_guid']."&trans_guid=".$_REQUEST['trans_guid'])
                );  
        };

        if ($_REQUEST['post_type'] =='trx_rec')
        {
            $data = array(
                'title' => 'POST BATCH TRANSFER IN',
                'content' => 'Post This Transaction: '.$_REQUEST['refno'],
                'back_button' => site_url('rbatch_controller/scan_batch'),
                'action' => site_url('main_controller/general_post?post_type=trx_rec&trans_guid='.$_REQUEST['trans_guid'])
                );
        };

        $browser_id = $_SERVER["HTTP_USER_AGENT"];
        if(strpos($browser_id,"Windows CE"))
            {
                $this->load->view('WinCe/header');
                $this->load->view('WinCe/confirm_post', $data);
            }
        else
            {
                $this->load->view('header');
                $this->load->view('confirm_post', $data);
                $this->load->view('footer');                
            }    


    }
    
    public function general_post()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {
            if ($_REQUEST['post_type'] =='trx_out')
            {
                $trans_guid = $_REQUEST['trans_guid'];
                $data = array(
                    'delivered' => '1',
                    'send_print' => '0',

                    'delivered_at' => $this->db->query("SELECT now() as datetime")->row('datetime'),
                    'delivered_by' => $_SESSION['username'],
                    );
                
                $this->Main_Model->general_post_trx_out($data,$trans_guid);
                redirect('obatch_controller/main');

            };

            if ($_REQUEST['post_type'] =='trx_rec_child')
            {
                $child_guid = $_REQUEST['child_guid'];
                $data = array(
                    'verified' => '1',
                    'verified_at' => $this->db->query("SELECT now() as datetime")->row('datetime'),
                    'verified_by' => $_SESSION['username'],
                    );

               $this->Main_Model->general_post_trx_rec_child($data, $child_guid);
               redirect('rbatch_controller/itemlist?trans_guid='.$_REQUEST['trans_guid']);

            };

            if ($_REQUEST['post_type'] =='trx_rec')
            {
                $trans_guid = $_REQUEST['trans_guid'];
                $data = array(

                    'received' => '1',
                    'received_at' => $this->db->query("SELECT now() as datetime")->row('datetime'),
                    'received_by' => $_SESSION['username'],
                    );
                
                $this->Main_Model->general_post_trx_rec($data, $trans_guid);
                $this->Main_Model->b_transfer_rec_post($trans_guid);
                redirect('rbatch_controller/main');

            };

            if ($_REQUEST['post_type'] =='grn_rec')
            {
                $grn_guid = $_REQUEST['grn_guid'];
                $data = array(
                    'received' => '1',
                    'received_at' => $this->db->query("SELECT now() as datetime")->row('datetime'),
                    'received_by' => $_SESSION['username'],
                    );

                $this->Main_Model->general_post_grn($data,$grn_guid);
                $this->db->query("UPDATE backend_warehouse.d_grn_batch set stock=1 where grn_guid='".$grn_guid."'");

                redirect('greceive_controller/po_list');

            };
            
        }
        else
        {
            redirect('main_controller');
        }

    }

    public function group_setting()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {
            $data = array(
                'user_group' => $this->db->query("SELECT group_name, a.user_group_guid, IFNULL(show_cost,0) AS show_cost FROM backend_warehouse.set_user_group AS a LEFT JOIN backend_warehouse.`set_user_group_setting` AS b ON a.`user_group_guid` = b.`user_group_guid`"), 
                );
            $this->load->view('header');
            $this->load->view('group_setting', $data);
            $this->load->view('footer');

        }
        else
        {
            redirect('main_controller');
        }
    }

    public function add_trans()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('username') != '')
        {
            $user_group_guid = $this->input->post('user_group_guid[]');

                    foreach($user_group_guid as $i => $guid) 
                    {
                        $check_record = $this->db->query("SELECT * FROM backend_warehouse.set_user_group_setting where user_group_guid = '$guid'");
                        $show_cost = $this->input->post('show_cost[]');
                        if($check_record->num_rows() == 0)
                        {
                            $data = array (
                            'user_group_guid' => $guid, 
                            'show_cost' => $show_cost[$i], 
                            );
                           /* echo $this->db->last_query();die;*/
                           $this->Main_Model->add_detail($data);
                        }
                        else
                        {
                            $data = array (
                            'show_cost' => $show_cost[$i], 
                            );
                           $this->Main_Model->update_details($data,$guid);
                        }
                    }
                    redirect('main_controller/group_setting');
                    
        }
        else
        {
            redirect('main_controller');
        }
    }
 
}
?>
